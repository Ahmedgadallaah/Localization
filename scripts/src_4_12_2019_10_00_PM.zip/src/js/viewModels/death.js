define(['ojs/ojcore', 'knockout', 'jquery', 'viewModels/helpers/ipConfig',
    'viewModels/helpers/fetcheandcache_persondeathinfo', 'viewModels/helpers/fetchandcache_persondetails', 'ojs/ojcheckboxset', 'ojs/ojformlayout', 'ojs/ojarraydataprovider', 'ojs/ojtable',
    'ojs/ojinputtext', 'ojs/ojbutton', 'ojs/ojpagingtabledatasource',
    'ojs/ojarraytabledatasource', 'ojs/ojpagingcontrol',
    'ojs/ojvalidationgroup', 'ojs/ojcollectiontabledatasource', 'ojs/ojmessages'
  ],
  function (oj, ko, $, ipConfig, deathInfo, detailInfo) {

    function CustomerViewModel() {
      var self = this;
      //self.fetchAllData = new fetchAllDataClass();
      self.tracker = ko.observable();
      self.groupValid = ko.observable();
      self.errorMessages = ko.observableArray([]);
      self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);

      self.personalIdentityNumber = ko.observable('');
      self.returnedDeathData = ko.observableArray([]);

      self.dataprovider = new oj.ArrayTableDataSource(self.returnedDeathData, {
        idAttribute: 'idNum',
        sortort: {
          key: 'idNum',
          direction: 'ascending'
        }
      });

      self.pagingDataProvider =
        new oj.PagingTableDataSource(self.dataprovider);


      self.isSearchButtonDisabled = ko.observable(true);
      self.identityNumMessages = ko.observableArray([]);
      self.personalIdentityNumber.subscribe(function (val) {
        self.identityNumMessages([]);
        self.isSearchButtonDisabled(false);
        console.log("Is Valid", isNaN(val));
        if ((val.length != 14) || isNaN(val)) {
          self.isSearchButtonDisabled(true);
          self.identityNumMessages.push({
            severity: "warning",
            summary: "الصيغة غير صحيحة",
            detail: "يجب أن يتم إدخال أرقام ويكون الرقم مكون من 14 رقم فقط"
          });
        } else {
          self.isSearchButtonDisabled(false);
        }

      })



      // self.dataprovider = new oj.ArrayDataProvider
      // (self.returnedDeathData, {
      //   keyAttributes: 'idNum',
      //   implicitSort: [{
      //     attribute: 'idNum',
      //     direction: 'ascending'
      //   }]
      // });

      self.columns = [{
          "headerText": "",
          "field": "idNum",
          "renderer": oj.KnockoutTemplateUtils.getRenderer("serial", true)
        },
        {
          "headerText": "الاسم الأول",
          "field": "firstName",
          "resizable": "enabled"
        },
        {
          "headerText": "رقم الهوية",
          "field": "idNum",
          "resizable": "enabled"
        },
        {
          "headerText": "الاسم الاول للوالد",
          "field": "fatherFirstName",
          "headerClassName": "oj-sm-only-hide",
          "className": "oj-sm-only-hide",
          "resizable": "enabled"
        },
        {
          "headerText": "الاسم الثاني للوالد",
          "field": "fatherSecondName",
          "resizable": "enabled",
          "className": "oj-sm-only-hide",
          "headerClassName": "oj-sm-only-hide",
          "resizable": "enabled"
        },
        {
          "headerText": "تاريخ الوفاة",
          "field": "deathDate",
          "resizable": "enabled"
        },
      ];


      // self.death = {
      //   "requestType": "63",
      //   "idNum": self.personalIdentityNumber(),
      //   "CSOHeader": {
      //     "OrganizationCode": "10-10",
      //     "UserName": "AZEID",
      //     "UserIdnum": "27508122700611",
      //     "TransactionNumber": "1010",
      //     "RequestTimeStamp": "2019-06-02 10:10:10.000000",
      //     "ResponseTimeStamp": ""
      //   }
      // }


      // self.url = "http://192.168.1.202:7003/CSO_SBProject/GetSpouseProfileRestService";

      // self.collection = null;
      // self.submit = function() {

      //   self.collection = new  oj.Collection(null,{customURL : function(){
      //           return self.url;
      //   }});

      //   self.collection.fetch({success:function(cols,reponse,options){
      //        console.log("Collection Data" , response);
      //   }});


      // }



      /*self.submit = function () {
        if (tracker.valid === "valid") {
          //self.death.idNum = self.personalIdentityNumber();
          // load icon
          document.getElementById("loader").style.visibility = "visible";
          document.getElementById("load").style.visibility = "visible";
          console.log("personalIdentityNumber", self.personalIdentityNumber());

          self.fetchAllData.setIdNumber(self.personalIdentityNumber());

          self.fetchAllData.deathInfoCallBack = function (data) {

          document.getElementById("loader").style.visibility = "hidden";
          document.getElementById("load").style.visibility = "hidden";


            console.log("returnedDeathData before",self.returnedDeathData());
            console.log("THE DATA",data);
            self.returnedDeathData.push(JSON.parse(JSON.stringify(data)));

            
            //self.returnedDeathData.push(data);
            console.log("returnedDeathData after",self.returnedDeathData());
           
          }

          self.errorCallBack = function (error) {
            document.getElementById("loader").style.visibility = "hidden";
            document.getElementById("load").style.visibility = "hidden";

            console.log("error", error);
          }

          self.fetchAllData.getData();

        
          // $.ajax({

          //   'type': 'POST',
          //   timeout: 0,
          //   'url': 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/GetDeathDetailsRestService',
          //   'data': JSON.stringify(self.death),
          //   'dataType': 'json',
          //   'contentType': 'application/json'
          // }).done(function (data) {
          //   document.getElementById("loader").style.visibility = "hidden";
          //   document.getElementById("load").style.visibility = "hidden";
          //   console.log("Returned Data", data);
          //   self.returnedDeathData(JSON.parse(JSON.stringify(data)));
          // }).fail();

        } else {
          tracker.showMessages();
          tracker.focusOn("@firstInvalidShown");
        }
      }


      self.tableListener = function () {

        var table = document.getElementById('table');
        console.log("current ROW", table.currentRow);
        if (table.currentRow == null) {
          return;
        }
        self.personalIdentityNumber(table.currentRow.rowKey);
        self.router = oj.Router.rootInstance;

        self.router.go('personDetails');
        window.localStorage.setItem('idnumber', self.personalIdentityNumber());

      }*/


      self.submit = function () {
        self.returnedDeathData([]);
        self.errorMessages([]);
        if (tracker.valid === "valid") {
          //self.death.idNum = self.personalIdentityNumber();
          // load icon
          document.getElementById("loader").style.visibility = "visible";
          document.getElementById("load").style.visibility = "visible";
          console.log("personalIdentityNumber", self.personalIdentityNumber());

          deathInfo.setIdNumber(self.personalIdentityNumber());
          detailInfo.setIdNumber(self.personalIdentityNumber());

          deathInfo.getData().then(function (data) {

            //alert("Death Info Success");
            if (typeof data === 'undefined') {

              self.errorMessages.push({
                severity: "error",
                summary: "خطأ",
                detail: "هذا الشخص لا يوجد له بيانات وفاة وهو علي قيد الحياة "
              });
              document.getElementById("loader").style.visibility = "hidden";
              document.getElementById("load").style.visibility = "hidden";
              return;
            }




            document.getElementById("loader").style.visibility = "hidden";
            document.getElementById("load").style.visibility = "hidden";


            console.log("returnedDeathData before", self.returnedDeathData());
            console.log("THE DATA", data);
            self.returnedDeathData.push(JSON.parse(JSON.stringify(data)));


            //self.returnedDeathData.push(data);
            console.log("returnedDeathData after", self.returnedDeathData());

          }).catch(function (error) {


            detailInfo.getData().then(function (data) {

              if (data.status == "نعم") {

                self.errorMessages.push({
                  severity: "error",
                  summary: "هذا الشخص على قيد الحياة ",
                  detail: "هذا الشخص على قيد الحياة "
                });
              }
              else{
                self.errorMessages.push({
                  severity: "error",
                  summary: "خطأ استرجاع بيانات الوفاة  ",
                  detail: error.statusText
                });
              }

            }).catch(function (error) {

              self.errorMessages.push({
                severity: "error",
                summary: "خطأ استرجاع بيانات الوفاة  ",
                detail: error.statusText
              });


            })

            document.getElementById("loader").style.visibility = "hidden";
            document.getElementById("load").style.visibility = "hidden";

            console.log("error", error);

          });


          //          self.fetchAllData.getData();

        } else {
          tracker.showMessages();
          tracker.focusOn("@firstInvalidShown");
        }
      }


      self.tableListener = function () {

        var table = document.getElementById('table');
        console.log("current ROW", table.currentRow);
        if (table.currentRow == null) {
          return;
        }
        self.personalIdentityNumber(table.currentRow.rowKey);
        self.router = oj.Router.rootInstance;

        self.router.go('personDetails');
        window.localStorage.setItem('idnumber', self.personalIdentityNumber());

      }





      self.connected = function () {

        var deathIdentity = document.getElementById("deathIdentity");
        console.log("element", deathIdentity);

        deathIdentity.addEventListener("keyup", function (event) {
          if (event.keyCode == 13 && self.isSearchButtonDisabled() != true) {

            self.submit();

          }
        });


      }

      self.disconnected = function () {
        self.errorMessages([]);
      }

    }

    return new CustomerViewModel();
  }
);