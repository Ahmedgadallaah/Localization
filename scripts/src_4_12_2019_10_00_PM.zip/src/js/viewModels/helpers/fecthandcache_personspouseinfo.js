define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCachePersonSpouseInfo() {
        var self = this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            self.idNumber = idnumber;
        }


        self.getData = function () {
            var cachedData = window.sessionStorage.getItem(self.idNumber + "spouseinfo");
            //  var cachedInfo = window.sessionStorage.getItem("spouseinfo"); 
            if (cachedData != null) {
                //  alert("Get Spouse Info from  Cache");

                return new Promise(function (resolve, reject) {
                    // cachedData = window.sessionStorage.getItem("spouseinfo");
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Spouse Info from Cache");
                    resolve(theData);
                });
            } else {
                var postData = {
                    "requestType": "62",
                    "idNum": self.idNumber,
                    "CSOHeader": {
                        "OrganizationCode": "10-10",
                        "UserName": "AZEID",
                        "UserIdnum": "27508122700611",
                        "TransactionNumber": "1010",
                        "RequestTimeStamp": "2019-06-02 10:10:10.000000",
                        "ResponseTimeStamp": ""
                    }
                }
                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/GetSpouseProfileRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Person Spouse Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        timeout: 0,
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',

                    }).done(function (data) {
                        console.log("SUCCESS Spouse Info Data", data);
                        //alert("Person Spouse");
                        // window.sessionStorage.setItem(self.idNumber + "spouseinfo", JSON.stringify(data));
                        resolve(data);

                        //  self.personaSpouseData(JSON.parse(JSON.stringify(data.ResponseSpouseProfile[0] )));
                        // console.log(self.personaSpouseData());
                    }).fail(function (error) {
                        reject(error);
                        console.log(error);
                    });


                });
            } //else
        }
    }

    return new FetchAndCachePersonSpouseInfo();

});