define([
    'jquery',
    'viewModels/helpers/ipConfig',
    'viewModels/helpers/fetchandcache_personinfo',
    'viewModels/helpers/fetcheandcache_persondeathinfo',
    'viewModels/helpers/fetchandcache_personvechils', 'viewModels/helpers/fecthandcache_personspouseinfo',
    'viewModels/helpers/fetchandcache_persondetails',
    'viewModels/helpers/fetchdataandcache_personidentity',
    'viewModels/helpers/fetchandcache_drivinglicense',
    'viewModels/helpers/fetchandcache_prisoners',
    'viewModels/helpers/fetchandcache_login',
    'viewModels/helpers/fetchandcache_authorize',


], function ($, ipConfig,
    personInfo, deathInfo, carInfo, spouseInfo, detailsInfo,
    identityInfo, driveInfo, prisonInfo, loginInfo, authInfo) {

    function FetchAndCacheAllData() {
        var self = this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            self.idNumber = idnumber;
        }

        self.personInfoCallBack = null;
        self.deathInfoCallBack = null;
        self.spouseInfoCallBack = null;
        self.carInfoCallBack = null;
        self.detailsInfoCallBack = null;
        self.identityInfoCallBack = null;
        self.erroCallBack = null;

        self.fillWhat = [];


        self.errorMessages = undefined;
        self.mainLoader = undefined;
        self.getData = function (errorMessages, mainLoader) {
            self.errorMessages = errorMessages;
            self.mainLoader = mainLoader;

            //console.log("Person Info class", personInfo);
            var lastIdNum = window.sessionStorage.getItem("lastIdNum");
            if (lastIdNum == null || self.idNumber != lastIdNum) {
                window.sessionStorage.clear();
                window.sessionStorage.setItem("lastIdNum", self.idNumber);
                console.log("Clear All Cach Data");
            }

            personInfo.setIdNumber(self.idNumber);
            deathInfo.setIdNumber(self.idNumber);
            spouseInfo.setIdNumber(self.idNumber);
            carInfo.setIdNumber(self.idNumber);
            detailsInfo.setIdNumber(self.idNumber);
            identityInfo.setIdNumber(self.idNumber);
            driveInfo.setIdNumber(self.idNumber);
            prisonInfo.setIdNumber(self.idNumber);
            loginInfo.setIdNumber(self.idNumber);
            authInfo.setIdNumber(self.idNumber);



            var promises = [];

            if (self.fillWhat.length == 0) {
                promises.push(self.getPersonInfoPromise());
                promises.push(self.getSpouseInfoPromise());
                promises.push(self.getCarInfoPromise());
                promises.push(self.getDeathInfoPromise());
                promises.push(self.getDetailsInfoPromise());
                promises.push(self.getIdentityInfoPromise());
                promises.push(self.getDriveInfoPromise());
                promises.push(self.getPrisonInfoPromise());
                promises.push(self.getLoginInfoPromise());
                promises.push(self.getAuthInfoPromise());
            } //if
            else {
                for (var i = 0; i < self.fillWhat.length; i++) {
                    var objPassed = self.fillWhat[i];
                    var type = typeof objPassed;
                    console.log("objPassed", objPassed);
                    var name = type == 'object' ? objPassed.name : objPassed;
                    var postData = type == 'object' ? objPassed.postData : undefined;
                    var loader = type == 'object' ? objPassed.loader : undefined;
                    switch (name) {
                        case "personInfo":

                            promises.push(self.getPersonInfoPromise(postData, loader));
                            break;
                        case "spouseInfo":
                            promises.push(self.getSpouseInfoPromise(postData, loader));
                            break;
                        case "carInfo":
                            promises.push(self.getCarInfoPromise(postData, loader));
                            break;
                        case "deathInfo":
                            promises.push(self.getDeathInfoPromise(postData, loader));
                            break;
                        case "detailsInfo":
                            promises.push(self.getDetailsInfoPromise(postData, loader));
                            break;
                        case "identityInfo":
                            promises.push(self.getIdentityInfoPromise(postData, loader));
                            break;
                        case "driveInfo":
                            promises.push(self.getDriveInfoPromise(postData, loader));
                            break;
                        case "prisonInfo":
                            promises.push(self.getPrisonInfoPromise(postData, loader));
                            break;
                        case "loginInfo":
                            promises.push(self.getLoginInfoPromise(postData, loader));
                            break;
                        case "authInfo":
                            promises.push(self.getAuthInfoPromise(postData, loader));
                            break;
                    }
                }
            } //else
            console.log("Promises", promises);
            //return Promise.all(promises);
            return new Promise(function (resolve, reject) {
                self.showMainLoader();
                Promise.all(promises).then(function (values) {
                    self.hideMainLoader();
                    resolve(values);
                }).catch(function (error) {
                    self.hideMainLoader()
                    reject(error);
                });
            })
        }

        self.hideMainLoader = function () {
            if (!self.mainLoader) return;
            var loader = self.mainLoader;
            setTimeout(function () {
                $("#" + loader).hide();
            }, 3000);

        }


        self.showMainLoader = function () {
            if (!self.mainLoader) return;
            var loader = self.mainLoader;

            $("#" + loader).show();

            console.log("LOADER", loader);
        }

        self.showLoader = function (loader) {
            if (loader) {
                $("#" + loader).show();
            }
            console.log("LOADER", loader);
        }

        self.hideLoader = function (loader) {
            setTimeout(function () {
                if (loader) $("#" + loader).hide();
            }, 3000);

        }

        self.objectToDash = function (data) {
            var isObject = function (val) {
                return typeof val === "object";
            }
            var iterate = function (obj) {
                for (k in obj) {
                    if (isObject(obj[k])) {
                        obj[k] = "--";
                    }
                }
            }
            data.forEach(function (item) {
                iterate(item);
            });
        }

        self.isValid = function (obj, error) {
            if (obj.success && obj.hasData) return true;
            if (!obj.success || !obj.hasData) {
                if (self.errorMessages) {
                    //alert("Must show Error messages")
                    console.log("errorMessages", self.errorMessages)
                    self.errorMessages.push({
                        severity: "error",
                        summary: "خطأ",
                        detail: obj.errorText + " " + error ? error : ""
                    });
                }
            }
            return false;
        }


        self.getAuthInfoPromise = function (postData, loader) {
            return new Promise(function (resolve, reject) {

                if (loader) self.showLoader(loader);
                authInfo.getData(postData)
                    .then(function (data) {
                        if (loader) self.hideLoader(loader);
                        console.log("FetchAllData Authorize Info Data", data);
                        var obj = {
                            success: true,
                            hasData: !(typeof data === 'undefined' || typeof data.userAuthorityOutput === 'undefined'),
                            name: "authInfo",
                            data: data,
                            errorText: (typeof data === 'undefined' || typeof data.userAuthorityOutput === 'undefined') ? "لايوجد بيانات سماحيات للمستخدم" : "",
                            error: null
                        };
                        // } else {
                        //     obj = {
                        //         success: true,
                        //         hasData: false,
                        //         name: "authInfo",
                        //         data: data,
                        //         errorText: "ليس لك الصلاحية للدخول علي هذا التطبيق",
                        //         error: null
                        //     };
                        // }
                        if (self.isValid(obj))
                            resolve(obj);
                        else
                            reject(obj)
                    }).catch(function (error) {
                        if (loader) self.hideLoader(loader);
                        console.log("FetchAllData Login Info Error", error);
                        var obj = {
                            success: false,
                            errorText: "خطأ ف استرجاع البيانات السماحيات للمستخدم",
                            name: "authInfo",
                            error: error,
                            data: null
                        };
                        self.isValid(obj, error);
                        reject(obj);
                    });
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });
        }




        //==============================getPersonInfoPromise==========================================
        self.getLoginInfoPromise = function (postData, loader) {
            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                loginInfo.getData(postData)

                    .then(function (data) {
                        if (loader) self.hideLoader(loader);
                        console.log("FetchAllData Login Info Data", data);

                        var obj;

                        if (data != null) {
                            obj = {
                                success: true,
                                hasData: !(typeof data === 'undefined' || typeof data.userLoginOutput === 'undefined'),
                                name: "loginInfo",
                                data: data,
                                errorText: (typeof data === 'undefined' || typeof data.userLoginOutput === 'undefined') ? "لايوجد بيانات  للمستخدم" : "",
                                error: null
                            };
                        } else {
                            obj = {
                                success: true,
                                hasData: false,
                                name: "loginInfo",
                                data: data,
                                errorText: "خطا فى الاسم او كلمة الس",
                                error: null
                            };
                        }
                        if (self.isValid(obj))
                            resolve(obj);
                        else
                            reject(obj)
                    }).catch(function (error) {
                        if (loader) self.hideLoader(loader);
                        console.log("FetchAllData Login Info Error", error);
                        reject({

                            success: false,
                            errorText: "خطأ ف استرجاع البيانات  للمستخدم",
                            name: "loginInfo",
                            error: error,
                            data: null
                        });
                    });
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });



        }

        self.getPrisonInfoPromise = function (postData, loader) {

            var isObject = function (val) {
                return typeof val === "object";
            }
            var isNaN = function (val) {
                return typeof val === "NaN";
            }
            var changeData = function (row) {
                for (k in row) {
                    if (k == 'startdate') {
                        row[k] = new Date(row[k]).toLocaleDateString()
                    }
                    if (k == 'enddate') {
                        row[k] = new Date(row[k]).toLocaleDateString()
                    }
                }
            }
            var iterate = function (obj) {
                for (k in obj) {
                    if (isObject(obj[k])) {
                        obj[k] = "";
                    }
                    if (isNaN(obj[k])) {
                        obj[k] = "";

                    }

                }
            }

            var processData = function (data) {
                data.forEach(function (item) {
                    iterate(item);
                    changeData(item);
                });
            }



            // prisonInfo.setPostData(postData);
            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                prisonInfo.getData(postData)
                    .then(function (data) {
                        console.log("FetchAll Data Prisoners", data);
                        if (loader) self.hideLoader(loader);
                        var bhasdata = data != null && !(typeof data === 'undefined' || typeof data.Prisoner === 'undefined');
                        var obj = {
                            success: true,
                            hasData: bhasdata,
                            name: "prisonInfo",
                            data: data,
                            errorText: !bhasdata ? "لايوجد بيانات  للمسجون" : "",
                            error: null
                        };
                        if (self.isValid(obj)) {
                            processData(obj.data.Prisoner);
                            resolve(obj);

                        } else
                            reject(obj)
                    }).catch(function (error) {
                        if (loader) self.hideLoader(loader);
                        var obj = {

                            success: false,
                            errorText: "خطأ ف استرجاع البيانات  للمسجون",
                            name: "prisonInfo",
                            error: error,
                            data: null
                        };
                        self.isValid(obj, error); //==to show error
                        reject(obj);
                    });
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });
        }



        self.getPersonInfoPromise = function (postData, loader) {
            // personInfo.setPostData(postData);

            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                personInfo.getData(postData)
                    .then(function (data) {

                        if (loader) self.hideLoader(loader);
                        var obj = {
                            success: true,
                            hasData: !(typeof data === 'undefined' || typeof data.ResponsePersonProfile === 'undefined'),
                            name: "personInfo",
                            data: data,
                            errorText: (typeof data === 'undefined') ? "لايوجد بيانات اساسيه للمواطن" : "",
                            error: null
                        };
                        if (self.isValid(obj)) {

                            resolve(obj);
                        } else {

                            reject(obj)
                        }
                    }).catch(function (error) {

                        if (loader) self.hideLoader(loader);
                        var obj = {
                            success: false,
                            errorText: "خطأ ف استرجاع البيانات الاساسيىه للمواطن",
                            name: "personInfo",
                            error: error,
                            data: null
                        };
                        self.isValid(obj, error); //==to show error

                        reject(obj);
                    });
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });

        } //getPersonInfoPromise
        //=================================getSpouseInfoPromise=========================================================
        self.getSpouseInfoPromise = function (postData, loader) {
            var sortFunc = function (data) {
                if (Array.isArray(data.ResponseSpouseProfile)) {
                    data.ResponseSpouseProfile.sort(function (a, b) {
                        if (a.eventDate < b.eventDate) return -1;
                        if (a.eventDate > b.eventDate) return 1;
                        return 0;
                    })
                }
            } ///sort func

            var changeData = function (obj) {
                for (i = 0; i < obj.length; i++) {
                    obj[i].spouseType = obj[i].spouseType.trim();
                    if (obj[i].spouseType == '1') {
                        obj[i].spouseType = 'قائمة';
                    } else if (obj[i].spouseType == '2') {
                        obj[i].spouseType = 'غير قائمة';
                    }
                }
                console.log("Spouse Marital State", obj);
            }
            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                spouseInfo.getData(postData).then(function (data) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: true,
                        hasData: !(typeof data === 'undefined' || typeof data.ResponseSpouseProfile === 'undefined'),
                        errorText: (typeof data === 'undefined' || typeof data.ResponseSpouseProfile === 'undefined') ? "لا يوجد معلومات زواج للمواطن" : "",
                        name: "spouseInfo",
                        error: null,
                        data: data
                    };
                    if (self.isValid(obj)) {
                        sortFunc(obj.data);
                        changeData(obj.data.ResponseSpouseProfile);

                        resolve(obj);
                    } else
                        reject(obj)
                }).catch(function (error) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: false,
                        errorText: "خطأ ف استرجاع معلومات الزواج للمواطن",
                        name: "spouseInfo",
                        error: error,
                        data: null
                    };
                    self.isValid(obj, error); //==to show error
                    reject(obj);
                })
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });



        } //getSpouseInfoPromise

        //======================================getCarInfoPromise==========================================
        self.getCarInfoPromise = function (postData, loader) {

            var isObject = function (val) {
                return typeof val === "object";
            }
            var isNaN = function (val) {
                return typeof val === "NaN";
            }

            var iterate = function (obj) {
                for (k in obj) {
                    if (isObject(obj[k])) {
                        obj[k] = "";
                    }
                    if (isNaN(obj[k])) {
                        obj[k] = "";

                    }

                }
            }

            var processData = function (data) {
                data.forEach(function (item) {
                    iterate(item);
                });

            }

            var filterArray = function (data) {
                return data.filter(function (ele) {
                    return ele.PLATENUM != "";
                });
            }

            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                carInfo.getData(postData).then(function (data) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: true,
                        hasData: !(typeof data === 'undefined' || typeof data.getTITInfoOutput === 'undefined'),
                        errorText: (typeof data === 'undefined' || typeof data.getTITInfoOutput === 'undefined') ? "لايوجد بيانات مركبات للمواطن" : "",
                        name: "carInfo",
                        error: null,
                        data: data
                    }
                    if (self.isValid(obj)) {
                        //self.objectToDash(obj.data.getTITInfoOutput);
                        processData(obj.data.getTITInfoOutput);
                        console.log("obj.data", obj.data);

                        obj.data.getTITInfoOutput =
                            filterArray(obj.data.getTITInfoOutput);

                        resolve(obj);
                    } else
                        reject(obj)
                }).catch(function (error) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: false,
                        errorText: "خطأ ف استرجاع بيانات المركبات للمواطن",
                        name: "carInfo",
                        error: error,
                        data: null
                    };
                    self.isValid(obj, error); //==to show error
                    reject(obj);
                })
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });

        } //getCarInfoPromise


        //================================getDetailsInfoPromise===============================================
        self.getDetailsInfoPromise = function (postData, loader) {

            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                detailsInfo.getData(postData).then(function (data) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: true,
                        hasData: !(typeof data === 'undefined'),
                        errorText: (typeof data === 'undefined') ? "لايوجد بيانات تفصيليه للمواطن" : "",
                        name: "detailsInfo",
                        error: null,
                        data: data
                    }
                    if (self.isValid(obj))
                        resolve(obj);
                    else
                        reject(obj)
                }).catch(function (error) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: false,
                        errorText: "خطأ ف استرجاع البيانات التفصيليه للمواطن",
                        name: "detailsInfo",
                        error: error,
                        data: null
                    };
                    self.isValid(obj, error); //==to show error
                    reject(obj);
                })
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });


        } //getDetailsInfoPromise

        //================================================getDeathInfoPromise=========================================
        self.getDeathInfoPromise = function (postData, loader) {


            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                deathInfo.getData(postData).then(function (data) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: true,
                        hasData: !(typeof data === 'undefined'),
                        errorText: (typeof data === 'undefined') ? "لايوجد بيانات وفاة للمواطن" : "",
                        name: "deathInfo",
                        error: null,
                        data: data
                    }
                    if (self.isValid(obj)) {

                        resolve(obj);
                    } else
                        reject(obj)
                }).catch(function (error) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: false,
                        errorText: "خطأ ف استرجاع بيانات الوفاة للمواطن",
                        name: "deathInfo",
                        error: error,
                        data: null
                    };
                    self.isValid(obj, error); //==to show error
                    reject(obj);
                })
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });



        } //  getDeathInfoPromise

        //=============================================================getIdentityInfoPromise===============================================
        self.getIdentityInfoPromise = function (postData, loader) {
            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                identityInfo.getData(postData).then(function (data) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: true,
                        errorText: "",
                        name: "identityInfo",
                        error: null,
                        data: data
                    };
                    if (self.isValid(obj))
                        resolve(obj);
                    else
                        reject(obj)

                }).catch(function (error) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: false,
                        errorText: "Error in retrieve data of Identity Info",
                        name: "identityInfo",
                        error: error,
                        data: null
                    };
                    self.isValid(obj, error); //==to show error
                    reject(obj);
                })
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });
        } //  getIdentityInfoPromise

        //=============================================================getDriveInfoPromise ===============================================

        self.getDriveInfoPromise = function (postData, loader) {
            var isObject = function (val) {
                return typeof val === "object";
            }
            var isNaN = function (val) {
                return typeof val === "NaN";
            }

            changeData = function (row) {
                for (k in row) {
                    if (k == 'ISSUEDATE') {
                        row[k] = new Date(row[k]).toLocaleDateString()
                    }
                    if (k == 'EXPIRYDATE') {
                        row[k] = new Date(row[k]).toLocaleDateString()
                    }
                }
            }

            var iterate = function (obj) {
                for (k in obj) {
                    if (isObject(obj[k])) {
                        obj[k] = "";
                    }
                    if (isNaN(obj[k])) {
                        obj[k] = "";

                    }
                }
            }


            var processData = function (data) {
                data.forEach(function (item) {
                    iterate(item);
                    changeData(item);
                });
            }

            return new Promise(function (resolve, reject) {
                if (loader) self.showLoader(loader);
                driveInfo.getData(postData).then(function (data) {
                    if (loader) self.hideLoader(loader);
                    var bhasdata = data != null && !(typeof data === 'undefined' || typeof data.getDLInfoOutput === 'undefined');
                    var obj = {
                        hasData: bhasdata,
                        success: true,
                        errorText: !bhasdata ? 'لا يوجد بيانات رخص القيادة للمواطن' : '',
                        name: "driveInfo",
                        error: null,
                        data: data
                    };

                    if (self.isValid(obj)) {
                        console.log("obj.data.getDLInfoOutput", obj);
                        processData(obj.data.getDLInfoOutput)
                        resolve(obj);
                    } else
                        reject(obj)


                }).catch(function (error) {
                    if (loader) self.hideLoader(loader);
                    var obj = {
                        success: false,
                        errorText: "خطأ في استرجاع بيانات رخص القيادة للمواطن in retrieve data of Identity Info",
                        name: "driveInfo",
                        error: error,
                        data: null
                    };

                    self.isValid(obj, error); //==to show error
                    reject(obj);
                })
            }).catch(function (error) {
                if (loader) self.hideLoader(loader);
                return error;
            });
        } //  getdriveInfoPromise
    }
    return FetchAndCacheAllData;
});