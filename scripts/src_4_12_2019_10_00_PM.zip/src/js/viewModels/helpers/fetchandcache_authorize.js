define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCachePrisoners() {
        var self =this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            self.idNumber = idnumber;
        }

        self.getData = function (requestData) {
            var cachedData = window.sessionStorage.getItem(self.idNumber+"personInfo");
            console.log("cached data",cachedData);
            if (cachedData != null) {
                
               // alert("cachedData is not null");

                return new Promise(function (resolve, reject) {
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Info from Cache");
                    resolve(theData);
                });

            } else {
               
                var postData =!requestData? {
                    "userid" : ""
                  }
                  :requestData;

                console.log("Login post Data: ", postData )
                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/USISEC_SBProject/UserAuthorityRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Login Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',
                        success: function (data) {
//alert("Person Info");
			console.log("Login Info DATA SUCCESS",data);
                         
                            
                            resolve(data);

                        }
                    }).fail(function (error) {
                        reject(error);
                        console.log(error);
                    });


                });



            } //====else

        }





    }

    return new FetchAndCachePrisoners();

});
