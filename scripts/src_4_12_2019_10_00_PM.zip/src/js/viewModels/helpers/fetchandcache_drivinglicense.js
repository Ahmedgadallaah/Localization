define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCacheDrivingLicense() {
        var self = this;

        self.plnum = "";
        self.setIdNumber = function (plnum) {
            // self.postData = undefined;
            self.plnum = plnum;
        }
        // self.postData;
        // self.setPostData = function (ppostdata) {
        //     self.postData = ppostdata;
        // }
        self.getData = function (requestData) {
            var cachedData = window.sessionStorage.getItem(self.plnum + "drivingLicense");
            console.log("cached data", cachedData);
            if (cachedData != null) {
                // alert("cachedData is not null");
                return new Promise(function (resolve, reject) {
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Info from Cache");
                    resolve(theData);
                });
            } else {
                var postData = !requestData ? {
                    "plnum": self.plnum,
                } : requestData;
                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/DL_SBProject/getDLInfoRestService';

                console.log("fetchandcache_drivinglicense REQUEST", postData);
                return new Promise(function (resolve, reject) {
                    console.log("Get Driving License Info Data from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',
                        success: function (data) {
                            //alert("Person Info");
                            console.log("Drive License Info DATA SUCCESS", data);
                            // window.sessionStorage.setItem(self.idNumber+"personInfo", JSON.stringify(data));
                            console.log("cached data saved for " + self.plnum, data);

                            resolve(data);
                        }
                    }).fail(function (error) {
                        reject(error);
                        console.log(error);
                    });
                });
            } //====else
        }
    }

    return new FetchAndCacheDrivingLicense();

});