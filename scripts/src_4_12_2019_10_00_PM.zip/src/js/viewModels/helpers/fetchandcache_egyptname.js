define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function Fetchandcache_egyptname () {
        var self =this;
        
        self.pname = "";
       

        self.setPname = function (pname) {
            self.pname = pname;
        }

        self.getData = function () {

            var cachedData = window.sessionStorage.getItem(self.pname+"personInfo");
                console.log("cached data",cachedData);
            if (cachedData != null) {
                
               // alert("cachedData is not null");

                return new Promise(function (resolve, reject) {
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Info from Cache");
                    resolve(theData);
                });



            } else {


                var postData = {
                    "pass_no" : " ",
                    "pass_no1" : " ",
                    "pname": self.pname,
                    "pbirthdatefrom" : "",
                    "pbirthdateto" : "",
                    "pport_id" : "",
                    "pmovement_type" : "",
                    "pmovementdatefrom" : "",
                    "pmovementdateto" : ""
                }
                console.log("post Data: ", postData )
                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/PASSPORTS_PORTS_SBProject/PortsEgyMovsRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Person Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',
                        success: function (data) {
                //alert("Person Info");
			        console.log("Person Info DATA SUCCESS",data);
                           // window.sessionStorage.setItem(self.idNumber+"personInfo", JSON.stringify(data
                            console.log("cached data saved for "+self.pname, data);
                         
                            
                            resolve(data);

                        }
                    }).fail(function (error) {
                        reject(error);
                        console.log(error);
                    });


                });



            } //====else

        }





    }

    return new Fetchandcache_egyptname();

});
