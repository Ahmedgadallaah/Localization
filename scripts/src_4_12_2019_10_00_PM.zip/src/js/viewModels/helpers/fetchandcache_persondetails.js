define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCachePersonDetails() {
        var self = this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            self.idNumber = idnumber;
        }



        self.getData = function () {

            var cachedData = window.sessionStorage.getItem(self.idNumber + "detailsinfo");

            //  var cachedInfo = window.sessionStorage.getItem("detailsinfo"); 
            if (cachedData != null) {

                return new Promise(function (resolve, reject) {

                 //   alert("DONE");

                    // cachedData = window.sessionStorage.getItem("detailsinfo");
                    var theData = JSON.parse(cachedData);


                    self.changeData(theData);

                    console.log("THE DATA ", theData);
                    console.log("Get Person Details Info from Cache");
                    resolve(theData);
                });



            } else {

                var postData = {
                    "requestType": "61",
                    "idNum": self.idNumber,
                    "fcn": "",
                    "CSOHeader": {
                        "OrganizationCode": "10-10",
                        "UserName": "AZEID",
                        "UserIdnum": "27508122700611",
                        "TransactionNumber": "1010",
                        "RequestTimeStamp": "2019-06-02 10:10:10.000000",
                        "ResponseTimeStamp": ""
                    }
                }

                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/GetPersonDetailsRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Person Details Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        timeout: 0,
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',

                    }).done(function (data) {

//alert("Person Details");
console.log("Mother & Father Id Number",data);


                        var obj = JSON.parse(JSON.stringify(data));

                        console.log("Data Returned", obj);
                        console.log("gender", obj.gender);


                        self.changeData(obj);

                //        window.sessionStorage.setItem(self.idNumber + "detailsinfo", JSON.stringify(obj));
                        //alert("OK Detaild Data");
                        resolve(obj);

                        //
                        // self.personalDetailsData(obj);
                        //   console.log('PERSON: ', self.personalDetailsData());
                    }).fail(function (error) {
                        console.log("Person Details ERROR", error);
                        reject(error);
                    });


                });



            } //====else

        }




        self.changeData = function (obj) {

            obj.gender = obj.gender.trim();
            obj.status = obj.status.trim();
            if (obj.status == '1')
                obj.status = 'نعم';
            else if (obj.status == '2')
                obj.status = 'لا';
            else if (obj.status == '3')
                obj.status = 'موقوف أمني';

            // self.personalDetailsData(obj);

            //console.log("Father Id Num", obj.fatherIdNum);

            // father birth day
            if (obj.fatherIdNum != null && obj.motherIdNum != null) {
                fatherBirthCentury = obj.fatherIdNum.substring(0, 1);

                if (fatherBirthCentury == 1) {
                    fatherBirthCentury = 18;
                } else if (fatherBirthCentury == 2) {
                    fatherBirthCentury = 19;
                } else {
                    fatherBirthCentury = 20;
                }

                fatherBirthYear = obj.fatherIdNum.substring(1, 3);
                fatherBirthMon = obj.fatherIdNum.substring(3, 5);
                fatherBirthDay = obj.fatherIdNum.substring(5, 7);

                //  console.log('fatherBirthDate', fatherBirthCentury + fatherBirthYear + '-' + fatherBirthMon + '-' + fatherBirthDay)
                obj.fatherBirthDate = fatherBirthCentury + fatherBirthYear + '-' + fatherBirthMon + '-' + fatherBirthDay;

                // mother birth day
                motherBirthCentury = obj.motherIdNum.substring(0, 1);

                if (motherBirthCentury == 1) {
                    motherBirthCentury = 18;
                } else if (motherBirthCentury == 2) {
                    motherBirthCentury = 19;
                } else {
                    motherBirthCentury = 20;
                }

                motherBirthYear = obj.motherIdNum.substring(1, 3);
                motherBirthMon = obj.motherIdNum.substring(3, 5);
                motherBirthDay = obj.motherIdNum.substring(5, 7);

                // console.log('motherBirthDate', motherBirthCentury + motherBirthYear + '-' + motherBirthMon + '-' + motherBirthDay)
                obj.motherBirthDate = motherBirthCentury + motherBirthYear + '-' + motherBirthMon + '-' + motherBirthDay;
            }

        }


    }

    return new FetchAndCachePersonDetails();

});
