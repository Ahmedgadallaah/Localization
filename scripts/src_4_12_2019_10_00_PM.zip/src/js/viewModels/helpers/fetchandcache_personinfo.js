define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCachePersonInfo() {
        var self = this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            // self.postData = undefined;
            self.idNumber = idnumber;
        }
        // self.postData;
        // self.setPostData = function (ppostData) {
        //     self.postData = ppostData;
        // }
        self.getData = function (requestData) {
            var cachedData = window.sessionStorage.getItem(self.idNumber + "personInfo");
            console.log("cached data", cachedData);
            if (cachedData != null) {
                return new Promise(function (resolve, reject) {
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Info from Cache");
                    resolve(theData);
                });
            } else {
                var postData = !requestData ? {
                    "requestType": "60",
                    "idNum": self.idNumber,
                    "firstName": "",
                    "fatherFirstName": "",
                    "fatherSecondName": "",
                    "familyName": "",
                    "birthDateStart": "",
                    "birthDateEnd": "",
                    "motherName": "",
                    "nickName": "",
                    "governorateCodeOfAddress": "",
                    "policestationCodeOfAddress": "",
                    "placeDescription": "",
                    "placeNo": "",

                    "CSOHeader": {
                        "OrganizationCode": "10-10",
                        "UserName": "AZEID",
                        "UserIdnum": "27508122700611",
                        "TransactionNumber": "1010",
                        "RequestTimeStamp": "2019-06-02 10:10:10.000000",
                        "ResponseTimeStamp": ""
                    }
                } : requestData;
                console.log("person Info Post Data:", requestData)
                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/GetPersonProfileRestService';

                console.log("fetchandcache_personinfo REQUEST", postData);

                return new Promise(function (resolve, reject) {
                    console.log("Get Person Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: JSON.stringify(postData),
                        contentType: 'application/json;charset=UTF-8',
                        dataType: 'json',
                        success: function (data) {
                            //alert("Person Info Success");
                            //alert("Person Info");
                            console.log("Person Info DATA SUCCESS", data);
                            // window.sessionStorage.setItem(self.idNumber+"personInfo", JSON.stringify(data));
                            console.log("cached data saved for " + self.idNumber, data);
                            resolve(data);

                        }
                    }).fail(function (error) {
                        //alert("Person Info Fail");
                        reject(error);
                        console.log(error);
                    });


                });



            } //====else

        }





    }

    return new FetchAndCachePersonInfo();

});