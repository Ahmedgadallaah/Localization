define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCachePersonVechiles() {
        var self = this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            // self.postData = undefined;
            self.idNumber = idnumber;
        }
        // self.postData;
        // self.setPostData = function (ppostdata) {
        //     self.postData = ppostdata;
        // }


        self.getData = function (requestData) {


            var cachedData = window.sessionStorage.getItem(self.idNumber + "carinfo");

            // var cachedInfo = window.sessionStorage.getItem("carinfo"); 
            if (cachedData != null) {

                return new Promise(function (resolve, reject) {
                    //  cachedData = window.sessionStorage.getItem("carinfo");
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Car Info from Cache");
                    resolve(theData);
                });

            } else {

                var postData = !requestData ? {
                    "pnum": self.idNumber,
                    "platenum": "",
                    "pnum1": self.idNumber,
                    "pnum2": self.idNumber,
                    "platenum1": "",
                    "ptype": "",
                    "govid": ""
                } : requestData;

                console.log("fetchandcache_personvechil REQUEST", postData);

                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/TIT_SBProject/TITInfoRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Person Car Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',

                    }).done(function (data) {
                        //alert("Person Car");
                        resolve(data);
                        // window.sessionStorage.setItem(self.idNumber + "carinfo", JSON.stringify(data));
                        // self.carsData(JSON.parse(JSON.stringify(data.getTITInfoOutput)));
                        //  console.log('Cars Data',self.carsData());
                    }).fail(function (error) {
                        reject(error);
                        console.log(error);
                    });
                });
            } //else
        }





    }

    return new FetchAndCachePersonVechiles();

});