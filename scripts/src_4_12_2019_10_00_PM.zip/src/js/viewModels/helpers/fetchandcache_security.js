define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCacheSecurity() {
        var self = this;
        self.getData = function (requestData) {
            var cachedData = window.sessionStorage.getItem(self.idNumber + "personInfo");
            console.log("cached data", cachedData);
            if (cachedData != null) {
                return new Promise(function (resolve, reject) {
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Info from Cache");
                    resolve(theData);
                });
            } else {
                var postData = !requestData ? {
                        "userid": ""
                    } :
                    requestData;

                console.log("Security post Data: ", postData)
                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/USISEC_SBProject/UserAuthorityRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Security Data Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',
                        success: function (data) {

                            console.log("Security Info DATA SUCCESS", data);

                            var d = self.getApplications(data.userAuthorityOutput);

                            resolve(d);

                        }
                    }).fail(function (error) {
                        reject(error);
                        console.log(error);
                    });
                });
            } //====else
        }
        self.getApplications = function (data) {
            var app = {};
            app.ahwal = {};
            app.cars = {};
            app.prisoners = {};
            app.passports = {};
            serviceData = {};


            serviceData.appIds = data.map(function (ele) {
                return ele.APP_ID;
            });
            serviceData.ahwalTransIds = data.filter(function (ele) {
                return ele.APP_ID == 5;
            }).map(function (el) {
                return el.TRANSACTION_ID;
            });
            serviceData.carsTransIds = data.filter(function (ele) {
                return ele.APP_ID == 6;
            }).map(function (el) {
                return el.TRANSACTION_ID;
            });

            serviceData.prisonersTransIds = data.filter(function (ele) {
                return ele.APP_ID == 7;
            }).map(function (el) {
                return el.TRANSACTION_ID;
            });

            serviceData.passportsTransIds = data.filter(function (ele) {
                return ele.APP_ID == 8;
            }).map(function (el) {
                return el.TRANSACTION_ID;
            });

            app.ahwal.visible = serviceData.appIds.includes(5);
            app.cars.visible = serviceData.appIds.includes(6);
            app.prisoners.visible = serviceData.appIds.includes(7);
            app.passports.visible = serviceData.appIds.includes(8)

            self.buildAhwal(serviceData, app.ahwal);
            self.buildCars(serviceData, app.cars);
            self.buildPrisoners(serviceData, app.prisoners);
            return app;
        }

        self.buildAhwal = function (serviceData, ahwal) {

            ahwal.NationalId = {};
            ahwal.others = {};

            ahwal.others.Address = {};
            ahwal.others.FullName = {};


            ahwal.others.FirstName_BirthDate = {};

            ahwal.others.FatherName = {};
            ahwal.others.MotherName = {};
            ahwal.others.Father_Mother_Name = {}

            ahwal.NationalId.has_50 = serviceData.ahwalTransIds.includes(50);
            ahwal.NationalId.has_57 = serviceData.ahwalTransIds.includes(57);
            ahwal.NationalId.has_58 = serviceData.ahwalTransIds.includes(58);
            ahwal.NationalId.visible = ahwal.NationalId.has_50 || ahwal.NationalId.has_57 || ahwal.NationalId.has_58;


            ahwal.others.Address.has_56 = serviceData.ahwalTransIds.includes(56);
            ahwal.others.Address.visible = ahwal.others.Address.has_56;

            ahwal.others.FullName.has_51 = serviceData.ahwalTransIds.includes(51);
            ahwal.others.FullName.visible = ahwal.others.FullName.has_51;


            ahwal.others.FirstName_BirthDate.has_52 = serviceData.ahwalTransIds.includes(52);
            ahwal.others.FirstName_BirthDate.visible = ahwal.others.FirstName_BirthDate.has_52;


            ahwal.others.FatherName.has_53 = serviceData.ahwalTransIds.includes(53);
            ahwal.others.FatherName.visible = ahwal.others.FatherName.has_53;


            ahwal.others.MotherName.has_54 = serviceData.ahwalTransIds.includes(54);
            ahwal.others.MotherName.visible = ahwal.others.MotherName.has_54;


            ahwal.others.Father_Mother_Name.has_55 = serviceData.ahwalTransIds.includes(55);
            ahwal.others.Father_Mother_Name.visible = ahwal.others.Father_Mother_Name.has_55;


            ahwal.others.visible = ahwal.others.Father_Mother_Name.visible ||
                ahwal.others.MotherName.visible || ahwal.others.FatherName.visible ||
                ahwal.others.FirstName_BirthDate.visible || ahwal.others.FullName.visible ||
                ahwal.others.Address.visible


        }


        self.buildCars = function (serviceData, cars) {

            cars.NationalId = {}; //==

            cars.PlateAplhaNum = {};
            cars.PlateNum = {};
            cars.PlateNum_LicenseType = {};
            cars.PlateNum_Gov = {};
            cars.PlateNum_LicenseType_Gov = {};


            cars.NationalId.has_60 = serviceData.carsTransIds.includes(60);
            cars.NationalId.has_66 = serviceData.carsTransIds.includes(66);

            cars.NationalId.visible = cars.NationalId.has_60 || cars.NationalId.has_66;

            cars.PlateAplhaNum.has_61 = serviceData.carsTransIds.includes(61);

            cars.PlateAplhaNum.visible = cars.PlateAplhaNum.has_61;

            cars.PlateNum.has_62 = serviceData.carsTransIds.includes(62);

            cars.PlateNum.visible = cars.PlateNum.has_62;

            cars.PlateNum_LicenseType.has_63 = serviceData.carsTransIds.includes(63);
            cars.PlateNum_LicenseType.visible = cars.PlateNum_LicenseType.has_63;



            cars.PlateNum_Gov.has_64 = serviceData.carsTransIds.includes(64);
            cars.PlateNum_Gov.visible = cars.PlateNum_Gov.has_64;


            cars.PlateNum_LicenseType_Gov.has_65 = serviceData.carsTransIds.includes(65);
            cars.PlateNum_LicenseType_Gov.visible = cars.PlateNum_LicenseType_Gov.has_65;






        }



        self.buildPrisoners = function (serviceData, prisoners) {

            prisoners.NationalId = {}; //==

            prisoners.Name = {};


            prisoners.NationalId.has_70 = serviceData.prisonersTransIds.includes(70);


            prisoners.NationalId.visible = prisoners.NationalId.has_70;



            prisoners.Name.has_71 = serviceData.prisonersTransIds.includes(71);


            prisoners.Name.visible = prisoners.Name.has_71;






        }



    }
    return new FetchAndCacheSecurity();
});