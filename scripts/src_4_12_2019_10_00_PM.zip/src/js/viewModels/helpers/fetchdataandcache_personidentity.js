define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCachePersonIdentity() {
        var self = this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            self.idNumber = idnumber;
        }



        self.getData = function () {

            var cachedData = window.sessionStorage.getItem(self.idNumber + "identityinfo");

           
           // var cachedInfo = window.sessionStorage.getItem("identityinfo"); 
            if (cachedData != null) {


                return new Promise(function (resolve, reject) {
                    //cachedData = window.sessionStorage.getItem("identityinfo");
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Identity from Cache");
                    resolve(theData);
                });



            } else {


                var postData = {
                    "requestType": "60",
                    "nationalIDNumber": self.idNumber,
                    "fcn": "string",
                    "CSOHeader": {
                        "OrganizationCode": "10-10",
                        "UserName": "AZEID",
                        "UserIdnum": "27508122700611",
                        "TransactionNumber": "1010",
                        "RequestTimeStamp": "2019-06-02 10:10:10.000000",
                        "ResponseTimeStamp": ""
                    }
                }
                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/CheckCitizenIdentityRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Person Identity from Server");
                    $.ajax({

                        'type': 'POST',
                        'url': url,
                        'data': JSON.stringify(postData),
                        'dataType': 'json',
                        'contentType': 'application/json',

                    }).done(function (data) {
//alert("Person Identity");
                        //window.sessionStorage.setItem(self.idNumber + "identityinfo", JSON.stringify(data));
                        resolve(data);
                    }).fail(function (error) {
                        console.log('Error: ', console.log(error));
                    });
                });



            } //====else

        }





    }

    return new FetchAndCachePersonIdentity();

});
