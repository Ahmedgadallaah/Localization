define([
    'viewModels/helpers/ipConfig',
    ''
], function (ipConfig) {

    function FetchAndCachePersonDeathInfo() {
        var self = this;
        self.idNumber = "";
        self.setIdNumber = function (idnumber) {
            self.idNumber = idnumber;
        }



        self.getData = function () {

            var cachedData = window.sessionStorage.getItem(self.idNumber + "deathinfo");
            // var cachedInfo = window.sessionStorage.getItem("deathinfo"); 
            if (cachedData != null) {

                return new Promise(function (resolve, reject) {
                    // cachedData = window.sessionStorage.getItem("deathinfo");
                    var theData = JSON.parse(cachedData);
                    console.log("Get Person Death Info from Cache");
                    resolve(theData);
                });
            } else {
                var postData = {
                    "requestType": "63",
                    "idNum": self.idNumber,
                    "CSOHeader": {
                        "OrganizationCode": "10-10",
                        "UserName": "AZEID",
                        "UserIdnum": "27508122700611",
                        "TransactionNumber": "1010",
                        "RequestTimeStamp": "2019-06-02 10:10:10.000000",
                        "ResponseTimeStamp": ""
                    }
                }

                var url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/GetDeathDetailsRestService';
                return new Promise(function (resolve, reject) {
                    console.log("Get Person Death Info from Server");
                    $.ajax({
                        url: url,
                        type: 'POST',
                        data: JSON.stringify(postData),
                        contentType: 'application/json',
                        dataType: 'json',

                    }).done(function (data) {
                        //alert("Person Death");
                        console.log("DEATH INFO SUCCESS ", data);
                        //window.sessionStorage.setItem(self.idNumber + "deathinfo", JSON.stringify(data));
                        data.gender = data.gender.trim();
                        self.maleOrFemale = function () {
                            // personalDetailsData().gender== '1' ? 'ذكر' : 'أنثي'
                            console.log("Male Or Female", self.personalDetailsData().gender)
                            if (self.personalDetailsData().gender == '1') return 'ذكر';
                            else if (self.personalDetailsData().gender == '2') return "انثى";
                            return '';
                        }
                        resolve(data);


                    }).fail(function (error) {
                        console.log("Death Info ERROR", error);
                        reject(error);

                    });


                });
            } ///else
        }





    }

    return new FetchAndCachePersonDeathInfo();

});