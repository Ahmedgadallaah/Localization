define(['ojs/ojcore', 'knockout', 'jquery', 'viewModels/helpers/ipConfig', 'viewModels/helpers/fetchandcache_alldata',
    'ojs/ojformlayout', , 'ojs/ojarraydataprovider', 'ojs/ojtable',
    'ojs/ojinputtext', 'ojs/ojbutton',
    'ojs/ojvalidationgroup', 'ojs/ojcollectiontabledatasource', 'ojs/ojmessages', 'ojs/ojmessage'
  ],
  function (oj, ko, $, ipConfig, fetchAllDataClass) {

    function AboutViewModel() {
      var self = this;
self.fetchAllData = new fetchAllDataClass();
      self.tracker = ko.observable();
      self.groupValid = ko.observable();
      self.personalIdentityNumber = ko.observable();
      self.status = ko.observable();

      // self.identityCheck =  {
      //   "requestType": "60",
      //   "nationalIDNumber": self.personalIdentityNumber(),
      //   "fcn": "string",
      //   "CSOHeader": {
      //     "OrganizationCode": "10-10",
      //     "UserName": "AZEID",
      //     "UserIdnum": "27508122700611",
      //     "TransactionNumber": "1010",
      //     "RequestTimeStamp": "2019-06-02 10:10:10.000000",
      //     "ResponseTimeStamp": ""
      //   }
      // }

      self.submit = function () {
        if (tracker.valid === "valid") {
          document.getElementById("loader").style.visibility = "visible";
          document.getElementById("load").style.visibility = "visible";
          self.fetchAllData.setIdNumber(self.personalIdentityNumber());
          self.fetchAllData.identityInfoCallBack = function (data) {
            
            self.status(data.rtStatus);
          };
          self.fetchAllData.errorCallBack = function (error) {
            
          }
          document.getElementById("loader").style.visibility = "hidden";
            document.getElementById("load").style.visibility = "hidden";
          self.fetchAllData.getData();
          //  $.ajax({

          //     'type': 'POST',
          //     'url': 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/CheckCitizenIdentityRestService',
          //     'data': JSON.stringify(self.identityCheck),
          //     'dataType': 'json',
          //     'contentType': 'application/json',

          //   }).done(function(data) {
          //     document.getElementById("loader").style.visibility = "hidden";
          //     document.getElementById("load").style.visibility = "hidden";
          //     self.status(data.rtStatus);
          //     console.log('DATA: ',self.status());
          //   }).fail(function(error) {
          //     // console.log('Error: ', console.log(error));
          //   });

        } else {
          // show messages on all the components 
          // that have messages hidden.
          tracker.showMessages();
          tracker.focusOn("@firstInvalidShown");
        }
      }

      self.insteadSearch = function () {

      }

    }

    return new AboutViewModel();
  }
);