/* 
 Changes To Login Javascript File
 */

/**
 * login module
 */
define(['ojs/ojcore', 'knockout', 'jquery',
    'appController', 'viewModels/helpers/fetchandcache_alldata', 'viewModels/helpers/fetchandcache_security', 'ojs/ojknockout',
    'ojs/ojlabel', 'ojs/ojinputtext', 'ojs/ojcheckboxset', 'ojs/ojselectcombobox', 'ojs/ojarraydataprovider', 'ojs/ojmessages'

], function (oj, ko, $, app, fetchCaheAllDataClass, securityInfo) {
    /**
     * The view model for the main content view template
     */
    function loginContentViewModel() {
        var self = this;

        self.fetchCaheAllData = new fetchCaheAllDataClass();
        self.username = ko.observable("المرور");
        self.password = ko.observable("المرور");
        self.login = ko.observable("Login");
        self.errorMessages = ko.observableArray([]);
        self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);
        self.validateMessages = ko.observable();
        self.doLogin = function (event) {
            //document.getElementById("loader").style.visibility = "visible";
            var loginRequest = {
                username: self.username(),
                password: self.password()
            };
            self.fetchCaheAllData.fillWhat = [{
                name: 'loginInfo',
                postData: loginRequest
            }];

            self.fetchCaheAllData.getData(self.errorMessages, 'login_loader').then(function (values) {
                // document.getElementById("load").style.visibility = "hidden";

                var info = values[0];
                console.log("Login Info", info);

                if (info.data.userLoginOutput[0].valid !== 1) {
                    self.errorMessages.push({
                        severity: "error",
                        summary: "خطأ",
                        detail: "خطا فى الاسم او كلمة السر"
                    });
                } else {
                    var userId = info.data.userLoginOutput[0].userid;
                    self.checkAuthorized(userId).then(function (userIsAuth) {
                        if (userIsAuth) {
                            var postData = {
                                userid: userId
                            };
                            securityInfo.getData(postData).then(function (data) {

                                app.setSecurityData(data);

                                console.log("Security Application Data", data)

                                setTimeout(() => {
                                    var startPage = "";
                                    if (data.ahwal.visible) startPage = "dashboard";
                                    else if (data.cars.visible) startPage = "vehicles";
                                    else if (data.prisoners.visible) startPage = "prisoners";
                                    else if (data.passports.visible) startPage = "passports";
                                    oj.Router.rootInstance.go(startPage).then(() => {

                                    })
                                }, 10)
                            })
                        } else {
                            self.errorMessages.push({
                                severity: "error",
                                summary: "خطأ",
                                detail: "لا توجد لهذا المستخدم أي صلاحية لإستخدام هذا التطبيق"
                            });
                        }
                    });
                }
            }).catch(function (error) {
                console.log("Login Info ERROR", error);
                self.errorMessages.push({
                    severity: "error",
                    summary: " خطأ استرجاع بيانات البحث ",
                    detail: error.statusText
                });
            });;
        } //=====do Login function
        self.checkAuthorized = function (userid) {
            var fetchData = new fetchCaheAllDataClass();
            fetchData.fillWhat = [{
                name: 'authInfo',
                postData: {
                    userid: userid
                }
            }];

            return new Promise(function (resolve, reject) {
                fetchData.getData(self.errorMessages, 'login_loader').then(function (values) {
                    var info = values[0];
                    if (info.success == false) {
                        self.errorMessages.push({
                            severity: "error",
                            summary: "خطأ",
                            detail: info.errorText
                        });
                        resolve(false);
                    } else if (info.hasData == false) {
                        self.errorMessages.push({
                            severity: "error",
                            summary: "خطأ",
                            detail: info.errorText
                        });
                        resolve(false);
                    } else {
                        var ar = info.data.userAuthorityOutput;
                        var tabsNumbers = [5, 6, 7, 8, 9];
                        isUserAuthorized = false;
                        var i = 0;
                        var ele;
                        for (i = 0; i < ar.length; i++) {
                            ele = ar[i];
                            if (tabsNumbers.includes(ele.APP_ID)) {
                                isUserAuthorized = true;
                                break;
                            }
                        }
                        resolve(isUserAuthorized);
                    }
                });
            });
        }

        self.connected = function () {
            // self.refresh(self.selectedLang());

            var username = document.getElementById("username");
            username.addEventListener("keyup", function (event) {
                if (event.keyCode == 13) {
                    passwordElem.focus();
                }
            });

            var passwordElem = document.getElementById("password");
            passwordElem.addEventListener("keyup", function (event) {
                if (event.keyCode == 13)
                    $("#submit").click();
            });
        }
    }


    return loginContentViewModel;
});