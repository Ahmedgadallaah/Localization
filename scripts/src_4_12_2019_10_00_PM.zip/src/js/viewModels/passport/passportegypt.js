/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your dashboard ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojmodule-element-utils',
    'viewModels/helpers/ipConfig', 'viewModels/helpers/mapping', 'viewModels/helpers/fetchandcache_egyptname', 'appController', 'ojs/ojformlayout',
    'ojs/ojinputtext', 'ojs/ojbutton', 'ojs/ojinputnumber', 'ojs/ojdatetimepicker', 'ojs/ojselectcombobox',
    'ojs/ojrouter', 'ojs/ojcollectiontabledatasource', 'ojs/ojarraydataprovider',
    'ojs/ojtable', 'ojs/ojinputtext', 'ojs/ojvalidationgroup', 'ojs/ojformlayout',
    'ojs/ojlabel', 'ojs/ojmessages', 'ojs/ojpagingtabledatasource',
    'ojs/ojarraytabledatasource', 'ojs/ojpagingcontrol' , 'ojs/ojradioset',
  ],
  function (oj, ko, $, moduleUtils, ipConfig, map, egyptname, app) {

    function PassportNumberEgypt(type) {
      var self = this;

      console.log("MAP", map);


      self.currentType = ko.observable(type);
      self.currentType.subscribe(function (val) {
        self.setPortsComboBox();
      });
      self.errorMessages = ko.observableArray([]);
      self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);
      self.scrollPos = ko.observable({
        rowIndex: 1
      });
      self.scrollPosInfo = ko.observable(null);
      self.clickedIndex = ko.observable("");



      self.currentSearchType = ko.observable(1);
      self.currentSearchType.subscribe(function (val) {
        self.resetVars();
      })





      self.redrivedData = ko.observableArray([]);
      self.tableValues = ko.observableArray([]);
      self.selectedTableValue = ko.observable();
      self.theports = ko.observableArray([]);




      self.ports = ko.observableArray([]);
      self.selectedPort = ko.observable('');

      self.portscards = ko.observableArray([]);
      self.selectedPortcard = ko.observable('');




      self.resetVars = function () {
        self.pname = ko.observable('');
        self.pass_no = ko.observable('');
        self.pass_no1 = ko.observable('');
        self.natid = ko.observable('');
        self.natid1 = ko.observable('');
        self.pissueyear = ko.observable('');
        self.ppasstype = ko.observable('');
        self.pissueplace = ko.observable('');
        self.pbirthdatefrom = ko.observable('');
        self.pbirthdateto = ko.observable('');
        self.pmovement_type = ko.observable('');
        self.pmovementdatefrom = ko.observable('');
        self.pport_id = ko.observable('');
        self.pmovementdateto = ko.observable('');
      }

      self.resetVars();

      self.getPortsUrl = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/PASSPORTS_PORTS_SBProject/getAllPortEgyRestService';
      self.getPorts = function () {

        $.ajax({
          url: self.getPortsUrl,
          type: 'GET',

        }).done(function (data) {

          self.ports(data.LkpPortsEgyPorts.map(function (item) {
            return {
              value: item.portId.toString(),
              label: item.portName
            }
          }));
          self.ports.unshift({
            value: '',
            label: "الجميع"
          });
          console.log('PORTS: ', self.ports());
          self.setPortsComboBox();
        }).fail(function (error) {



          console.log(error);
        });
      };

      self.getPorts();




      self.getPortsUrlcard = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/ExitEntryEgy_SBProject/getAllPortsEgyRestService';
      self.getcardPorts = function () {

        $.ajax({
          url: self.getPortsUrlcard,
          type: 'GET',

        }).done(function (data) {

          self.portscards(data.LkpExitEgyGeo.map(function (item) {
            return {
              value: item.geoId.toString(),
              label: item.geoName
            }
          }));
          self.portscards.unshift({
            value: '',
            label: "الجميع"
          });
          console.log('PORTS: ', self.portscards());
          self.setPortsComboBox();
        }).fail(function (error) {
          console.log(error);
        });
      };

      self.getcardPorts();


      self.tableValues = [{
          id: '1',
          label: 'منافذ'
        },
        {
          id: '2',
          label: 'كروت'
        }
      ];

      // observable bound to the Buttonset:
      self.selectedTableValue = ko.observable(1);


      self.moduleConfig = ko.observable({
        'view': [],
        'viewModel': null
      });










      self.cellData = function (cell) {
        console.log("CELL DATA", cell);
        return cell.data;
      }

      self.postDataPorts = {

      }


      self.postDataCards = {

      }



      self.setPostData = function () {
        self.postDataPorts = {
          "pass_no": self.pass_no().length == 0 ? ' ' : self.pass_no(),
          "pass_no1": self.pass_no().length == 0 ? ' ' : self.pass_no(),
          "pname": self.pname(),
          "pbirthdatefrom": self.dateToNumber(self.pbirthdatefrom()),
          "pbirthdateto": self.dateToNumber(self.pbirthdateto()),
          "pport_id": self.pport_id(),
          "pmovement_type": self.pmovement_type(),
          "pmovementdatefrom": self.dateToNumber(self.pmovementdatefrom()),
          "pmovementdateto": self.dateToNumber(self.pmovementdateto()),
        }
        self.postDataCards = {
          "pass_no": self.pass_no().length == 0 ? ' ' : self.pass_no(),
          "natid": self.natid().length == 0 ? ' ' : self.natid(),
          "pass_no1": self.pass_no().length == 0 ? ' ' : self.pass_no(),
          "natid1": self.natid().length == 0 ? ' ' : self.natid(),
          "pname": self.pname(),
          "pbirthdatefrom": self.dateToNumber(self.pbirthdatefrom()),
          "pbirthdateto": self.dateToNumber(self.pbirthdateto()),
          "pport_id": self.pport_id(),
          "pmovement_type": self.pmovement_type(),
          "pmovementdatefrom": self.dateToNumber(self.pmovementdatefrom()),
          "pmovementdateto": self.dateToNumber(self.pmovementdateto()),
          "pissueyear": self.pissueyear(),
          "ppasstype": self.ppasstype(),
          "pissueplace": self.pissueplace()






        }
      }

      self.leadingZero = function (num) {

        var numAsStr = num.toString();
        if (numAsStr.length == 2) return numAsStr;
        return "0" + numAsStr;
      }

      self.dateToNumber = function (dt) {

        if (dt == null || dt.length == 0) return "";
        var d = new Date(dt);
        month = '' + (d.getMonth() + 1),
          day = '' + d.getDate(),
          year = d.getFullYear();

        if (month.length < 2)
          month = '0' + month;
        if (day.length < 2)
          day = '0' + day;

        return [year, month, day].join('');

      }

      console.log(self.url);
      self.setPortsComboBox = function () {
        if (self.currentType() == 1) {
          self.theports(self.portscards());
        } else if (self.currentType() == 2) {
          self.theports(self.ports());
        }
      }
      self.doSearch = function () {
        if (self.currentType() == 1) self.doSearchCards();
        else if (self.currentType() == 2) self.doSearchPorts();
      }
      self.doSearchPorts = function () {
        self.redrivedData([]);
        self.errorMessages([]);
        document.getElementById("load").style.visibility = "visible";
        document.getElementById("loader").style.visibility = "visible";

        self.setPostData();
        console.log('Passport Number Egypt Post Data Ports', self.postDataPorts);

        self.refreshModule("egyptports", self.postDataPorts);
      }


      self.doSearchCards = function () {
        self.redrivedData([]);
        self.errorMessages([]);
        document.getElementById("load").style.visibility = "visible";
        document.getElementById("loader").style.visibility = "visible";

        self.setPostData();
        console.log('Passport Number Egypt Post Data Cards', self.postDataCards);
        self.refreshModule("egyptcards", self.postDataCards);
      }


      self.refreshModule = function (moduleName, postData) {
        var viewPath = 'views/passport/' + moduleName + '.html';
        var modelPath = 'viewModels/passport/' + moduleName;
        var masterPromise = Promise.all([
          moduleUtils.createView({
            'viewPath': viewPath
          }),
          moduleUtils.createViewModel({
            'viewModelPath': modelPath
          })
        ]);
        return masterPromise.then(
          function (values) {
            console.log("VALUES", values);
            var vModel = values[1];

            console.log("View Model", vModel);

            vModel = new values[1]();

            vModel.setPostData(postData);

            var finalViewModel = values[1];
            self.moduleConfig({
              'view': values[0],
              'viewModel': vModel
            });
          }
        ); //---then


      } //====setModuleConfig






      self.tableListener = function () {
        var table = document.getElementById('table');
      }
    }

    return PassportNumberEgypt;
  }
);