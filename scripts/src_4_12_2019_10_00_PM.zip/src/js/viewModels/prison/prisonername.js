define(['ojs/ojcore', 'knockout', 'jquery',
    'viewModels/helpers/ipConfig', 'viewModels/helpers/mapping', 
    'viewModels/helpers/fetchandcache_prisoners', 'appController', 'ojs/ojformlayout',
    'ojs/ojinputtext', 'ojs/ojinputnumber', 'ojs/ojdatetimepicker', 'ojs/ojselectcombobox',
    'ojs/ojrouter', 'ojs/ojcollectiontabledatasource', 'ojs/ojarraydataprovider',
    'ojs/ojtable', 'ojs/ojinputtext', 'ojs/ojvalidationgroup', 'ojs/ojformlayout',
    'ojs/ojlabel', 'ojs/ojmessages', 'ojs/ojpagingtabledatasource',
    'ojs/ojarraytabledatasource', 'ojs/ojpagingcontrol'
  ],
  function (oj, ko, $, ipConfig, map, prison, app) {

    function PrisonerNameViewModel() {
      var self = this;

      console.log("MAP", map);
      
      self.errorMessages = ko.observableArray([]);
      self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);
      self.scrollPos = ko.observable({
        rowIndex: 1
      });

      self.tracker = ko.observable();
      self.groupValid = ko.observable();
      self.idValue = ko.observable('');
      self.nationalIdNum = ko.observable('');
      self.redrivedData = ko.observableArray([]);
      self.selection = ko.observable(true);
      self.scrollPosInfo = ko.observable(null);
      self.clickedIndex = ko.observable("");
      self.nationalIdNum = ko.observable('');
      self.name = ko.observable('');

      self.columns = [{
        "headerText": "",
        "field": "natid",
        "renderer": oj.KnockoutTemplateUtils.getRenderer("serial", true)
    },
{
        "headerText": "الرقم القومي",
        "field": "natid",
        "headerClassName": "oj-sm-only-hide",
        "className": "oj-sm-only-hide",
        "resizable": "enabled"
    },
    {
        "headerText": "الاسم الكامل",
        "field": "fullname",
        "headerClassName": "oj-sm-only-hide",
        "className": "oj-sm-only-hide",
        "resizable": "enabled"
    },
    {
        "headerText": "التهمة",
        "field": "accusation",
        "resizable": "enabled"
    },
    {
        "headerText": "الحكم",
        "field": "judgment",
        "headerClassName": "oj-sm-only-hide",
        "className": "oj-sm-only-hide",
        "resizable": "enabled"
    },
    {
        "headerText": "فئة المسجون",
        "field": "prisclass",
        "resizable": "enabled"
    },
    {
        "headerText": "السجن",
        "field": "prison",
        "resizable": "enabled"
    },
    {
        "headerText": "المحافظة",
        "field": "gov",
        "resizable": "enabled"
    },
    {
        "headerText": "المدينة",
        "field": "city",
        "resizable": "enabled"
    },
    {
        "headerText": "الحي",
        "field": "address",
        "resizable": "enabled"
    },

    {
        "headerText": "مبدأ",
        "field": "startdate",
        "resizable": "enabled"
    },

    {
        "headerText": "نهاية",
        "field": "enddate",
        "resizable": "enabled"
    },
    {
        "headerText": "تاريخ الإفراج",
        "field": "AddressDetails",
        "resizable": "enabled"
    }
      ];

      
      self.dataprovider = new oj.ArrayTableDataSource(self.redrivedData, {
        idAttribute: 'natid',
        sortCriteria: {
          key: 'natid',
          direction: 'ascending'
        }
      });

      self.pagingDataProvider = new oj.PagingTableDataSource(self.dataprovider);

      self.url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/Prisons_SBProject/PrisonerInfoRestService';
      
      self.isButtonDisabled = ko.computed(function () {
        var bool = self.name().length == 0
        console.log("IsButtonDisabled", bool);
        return bool;
      });


     
      self.doSearch = function (event) {
        self.errorMessages([]);
        self.redrivedData([]);
        if (tracker.valid == 'valid') {
            document.getElementById("loader").style.visibility = "visible";
            document.getElementById("load").style.visibility = "visible";

            // self.postData.natid = self.idValue();

            prison.setFname(self.name());
            prison.setIdNumber('');

                prison.getData().then(function (data) {
                  document.getElementById("loader").style.visibility = "hidden";
                  document.getElementById("load").style.visibility = "hidden";

                  console.log("prisoner data FETCH ALL DATA VALUES", data);

                  if (typeof data.Prisoner === 'undefined' ) {

                      self.errorMessages.push({
                          severity: "error",
                          summary: "خطأ",
                          detail: "لاتوجد بيانات للمواطن "
                      })
                      return
                  }
                  console.log("Data Retrieved" , data);
                  var obj = JSON.parse(JSON.stringify(data.Prisoner));
                  if (data != null) {
                      document.getElementById("loader").style.visibility = "hidden";
                      document.getElementById("load").style.visibility = "hidden";
        
                     // self.status(0);
                      self.redrivedData(obj);
                      var change = data.Prisoner;
                      change.forEach(function(ele){
                                 
                          self.changeData(ele);
                              
                      })
                      self.redrivedData(change);
                      scrollTo(0, 500);
                      console.log('Prisoners Data: ', self.redrivedData());
                      console.log('Data: ', data);
                  } else {
                     // self.status(1);
                      self.redrivedData.removeAll();
                    }   
                  
          
              }).catch(function (error) {
                  document.getElementById("loader").style.visibility = "hidden";
                  document.getElementById("load").style.visibility = "hidden";
      
                  self.errorMessages.push({
                      severity: "error",
                      summary: "خطأ",
                      detail: "لاتوجد بيانات المواطن الاساسيه"
                  });
                  console.log("error", error);
                });
          
        }
        else {
            tracker.showMessages();
            tracker.focusOn("@firstInvalidShown");
        }



          }

      // self.renderRow = function (p1) {
      //   console.log("ROW RENDER :", p1);
      // }

      // self.handleScrollPosition = function (event) {
      //   var info = event.detail.value;
      //   // alert("Scroll Changed rowindex : " + info.rowIndex);
      //   self.scrollPosInfo(info);
      // }

      // self.connected = function () {
      //   if (self.clickedKey() !== '') {
      //   alert("Connected " + self.clickedKey());
      //   self.scrollPos({
      //   rowKey: self.clickedKey()
      //   });
      //   }
      // }




      // self.transitionCompleted = function () {
      //   if (self.clickedIndex() !== '') {

      //     self.selectRowIndex(self.clickedIndex());

      //   }
      // }
      // self.selectRowIndex = function (index) {
      //   table = document.getElementById("table");
      //   table.selection = [{
      //     startIndex: {
      //       "row": index
      //     },
      //     endIndex: {
      //       "row": index
      //     }
      //   }];
      // }

      // self.showFunc = function () {
      //   //alert("Show Func");
      // }

      // self.serialize = function () {
      //   console.log("Self Object", self);
      //   self.firstName("Ayman");
      //   var st = ko.toJSON(self);
      //   self.firstName("No Ayman");
      //   console.log("Serialize String", st);
      //   window.localStorage.setItem("ser", st);
      // }


      // self.deserialize = function () {
      //   var st = window.localStorage.getItem("ser");

      //   // Every time data is received from the server:
      //   var vm = {};
      //   vm = map.fromJSON(st);
      //   Object.assign(vm, self);
      //   vm.showFunc();
      //   console.log("VM After JSON Deserilize", vm);


      //   Object.assign(vm, self);


      //   console.log("VM After Assign Object", vm);


      //   //dash.changeViewModel(vm,"searchothers");
      //   //map.fromJS(st,vm);
      //   //Object.assign(this,vm);
      //   //self = this;
      //   console.log("After Mapping", self);
      //   console.log("Paging Data Provider", self.pagingDataProvider);

      //   var table = document.getElementById('table');
      //   //table.setProperty("data",self.pagingDataProvider);
      //   console.log("Table Data", table.data);
      //   //table.data = self.pagingDataProvider ;
      //   table.refresh();
      //   return;

      //   var obj = JSON.parse(st);
      //   console.log("The deserializeed Object", obj);
      //   Object.assign(self, obj);

      //   console.log("After Assign Object", self);
      //   self.redrivedData = ko.observableArray(self.redrivedData);



      //   console.log("deSerialize", obj);
      // }


      // self.clearTable = function () {
      //   var o = self.redrivedData()[0];

      //   console.log("O", self.redrivedData()[0]);
      //   self.dataprovider.reset([]);
      //   self.redrivedData.removeAll();
      //   //self.redrivedData.push([o]);
      // }

      self.changeData = function (row) {
        for(k in row)
        {
            if(k=='startdate')
            {
                row[k]=new Date(row[k]).toLocaleDateString()
            }
            if(k=='enddate')
            {
                row[k]=new Date(row[k]).toLocaleDateString()
            }
        }
    }

      self.tableListener = function () {
        var table = document.getElementById('table');

        var currentStateofviewModel = {
          name: 'searchothers',
          state: '/dashboard/searchothers',
          gridIndex: table.currentRow.rowIndex,
          idNumber:window.localStorage.getItem('idnumber'),
          viewModel: self//map.toJSON(self,mapping)
        }
        console.log("to JS",currentStateofviewModel.viewModel);
        
        app.addHistory(currentStateofviewModel);

        self.clickedIndex(table.currentRow.rowIndex);
        self.nationalIdNum(table.currentRow.rowKey);
      
        self.router = oj.Router.rootInstance;
      //  self.router.go('personDetails');

        window.localStorage.setItem('idnumber', self.nationalIdNum());
      }
    }

    return PrisonerNameViewModel;
  }
);
