/**
 * @license
 * Copyright (c) 2014, 2018, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your dashboard ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery',
    'viewModels/helpers/ipConfig', 'viewModels/helpers/mapping', 'viewModels/dashboard', 'appController', 'ojs/ojformlayout',
    'ojs/ojinputtext', 'ojs/ojinputnumber', 'ojs/ojdatetimepicker', 'ojs/ojselectcombobox',
    'ojs/ojrouter', 'ojs/ojcollectiontabledatasource', 'ojs/ojarraydataprovider',
    'ojs/ojtable', 'ojs/ojinputtext', 'ojs/ojvalidationgroup', 'ojs/ojformlayout',
    'ojs/ojlabel', 'ojs/ojmessages', 'ojs/ojpagingtabledatasource',
    'ojs/ojarraytabledatasource', 'ojs/ojpagingcontrol'
  ],
  function (oj, ko, $, ipConfig, map, dash, app) {

    function SearchOthersViewModel() {
      var self = this;

      console.log("MAP", map);



      self.errorMessages = ko.observableArray([]);
      self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);
      self.scrollPos = ko.observable({
        rowIndex: 1
      });
      self.govs = ko.observableArray([]);
      self.selectedGov = ko.observable('');
      self.scrollPosInfo = ko.observable(null);
      self.clickedIndex = ko.observable("");
      self.nationalIdNum = ko.observable('');
      self.redrivedData = ko.observableArray();
      self.columns = [{
          "headerText": "",
          "field": "idNum",
          "renderer": oj.KnockoutTemplateUtils.getRenderer("serial", true)
        },

        {
          "headerText": "الاسم الكامل",
          "field": "fullName",
          "headerClassName": "oj-sm-only-hide",
          "className": "oj-sm-only-hide",
          "resizable": "enabled"
        },


        {
          "headerText": "رقم الهوية",
          "field": "idNum",
          "resizable": "enabled"
        },
        {
          "headerText": "محافظة الميلاد",
          "field": "governorateDescrOfBirth",
          "headerClassName": "oj-sm-only-hide",
          "className": "oj-sm-only-hide",
          "resizable": "enabled"
        },
        {
          "headerText": "تفاصيل العنوان",
          "field": "AddressDetails",
          "resizable": "enabled"
        }
      ];

      self.getGovsUrl = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/TIT_SBProject/GetGovsRestService';
      self.getGovs = function () {

        $.ajax({
          url: self.getGovsUrl,
          type: 'GET',

        }).done(function (data) {

          self.govs(data.Gov.map(function (item) {
            return {
              value: item.govname,
              label: item.govname
            }
          }));
          self.govs.unshift({
            value: "",
            label: "الجميع"
          });
          console.log('GOVS: ', self.govs());
        }).fail(function (error) {



          console.log(error);
        });
      };

      self.getGovs();

      self.dataprovider = new oj.ArrayTableDataSource(self.redrivedData, {
        idAttribute: 'idNum',
        sortCriteria: {
          key: 'idNum',
          direction: 'ascending'
        }
      });

      self.pagingDataProvider =
        new oj.PagingTableDataSource(self.dataprovider);

      self.idValue = ko.observable('');

      self.url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/GetPersonProfileRestService';
      self.firstName = ko.observable('');
      self.familyName = ko.observable('');
      self.fatherFirstName = ko.observable('');
      self.fatherSecondName = ko.observable('');
      self.birthDateStart = ko.observable('');
      self.birthDateEnd = ko.observable('');
      self.motherName = ko.observable('');
      self.nickName = ko.observable('');
      self.governorateCodeOfAddress = ko.observable('');
      self.policestationCodeOfAddress = ko.observable('');
      self.placeDescription = ko.observable('');
      self.placeNo = ko.observable('');


      self.isButtonDisabled = ko.computed(function () {
        var bool = self.firstName().length == 0 &&
          self.familyName().length == 0 &&
          self.fatherFirstName().length == 0 &&
          self.fatherSecondName().length == 0 &&
          self.birthDateStart().length == 0 &&
          self.birthDateEnd().length == 0 &&
          self.motherName().length == 0 &&
          self.nickName().length == 0 &&
         // self.governorateCodeOfAddress().length == 0 &&
          self.policestationCodeOfAddress().length == 0 &&
          self.placeDescription().length == 0 &&
          self.placeNo().length == 0;
        console.log("IsButtonDisabled", bool);
        return bool;
      });

      self.cellData = function (cell) {
        console.log("CELL DATA", cell);
        return cell.data;
      }

      self.postData = {
        "requestType": "61",
        "idNum": self.idValue(),
        "firstName": self.firstName(),
        "fatherFirstName": self.fatherFirstName(),
        "fatherSecondName": self.fatherSecondName(),
        "familyName": self.familyName(),
        "birthDateStart": self.birthDateStart(),
        "birthDateEnd": self.birthDateEnd(),
        "motherName": self.motherName(),
        "nickName": self.nickName(),
        "governorateCodeOfAddress": "",
        "policestationCodeOfAddress": "",
        "placeDescription": self.placeDescription(),
        "placeNo": self.placeNo(),

        "CSOHeader": {
          "OrganizationCode": "10-10",
          "UserName": "AZEID",
          "UserIdnum": "27508122700611",
          "TransactionNumber": "1010",
          "RequestTimeStamp": "2019-06-02 10:10:10.000000",
          "ResponseTimeStamp": ""
        }
      }


      console.log(self.url);

      self.getData = function () {


        console.log("POST DATA", self.postData);

        return new Promise(function (resolve, reject) {
          $.ajax({
            url: self.url,
            type: 'POST',
            data: JSON.stringify(self.postData),
            contentType: 'application/json;charset=UTF-8',
            dataType: 'json',
            success: function (data) {
              console.log('success data: ', data);
              resolve(data);
            },
            error: function (error) {
              reject(error);
              console.log('Error: ', error);
            }

          });

        })
      };

      self.doSearch = function () {
console.log("Selected Gov" , self.governorateCodeOfAddress());
        self.redrivedData([]);
        self.errorMessages([]);
        document.getElementById("load").style.visibility = "visible";
        document.getElementById("loader").style.visibility = "visible";


        self.postData.firstName = self.firstName();

        self.postData.fatherFirstName = self.fatherFirstName();
        self.postData.fatherSecondName = self.fatherSecondName();
        self.postData.familyName = self.familyName();
        self.postData.birthDateStart = self.birthDateStart();
        self.postData.birthDateEnd = self.birthDateEnd();
        self.postData.motherName = self.motherName();
        self.postData.nickName = self.nickName();
        self.postData.governorateCodeOfAddress = self.governorateCodeOfAddress();
        self.postData.policestationCodeOfAddress = self.policestationCodeOfAddress();
        self.postData.placeDescription = self.placeDescription();
        self.postData.placeNo = self.placeNo();

        console.log('Post Data:', self.postData);


        self.getData().then(function (data) {
          document.getElementById("load").style.visibility = "hidden";
          document.getElementById("loader").style.visibility = "hidden";

          console.log('Data: ', data);
          if (typeof data.ResponsePersonProfile === 'undefined') {

            self.errorMessages.push({
              severity: "error",
              summary: "خطأ",
              detail: "لاتوجد بيانات "
            });

            return;
          }
          console.log('The Data OTHERS', data.ResponsePersonProfile);
          var retrivedData = JSON.parse(JSON.stringify(data.ResponsePersonProfile));
          self.redrivedData(retrivedData);
          try {
            for (var i = 0; i < 100; i++) {
              var c = self.clone(retrivedData[0]);
              //self.redrivedData.push(c);
            }
          } catch (er) {
            console.log("try catch Error", er);
          }

        }).catch(function (error) {
          console.log("Search ERROR", error);
          self.errorMessages.push({
            severity: "error",
            summary: " خطأ استرجاع بيانات البحث ",
            detail: error.statusText
          });
        });
      }



      self.renderRow = function (p1) {
        console.log("ROW RENDER :", p1);
      }
      self.handleScrollPosition = function (event) {
        var info = event.detail.value;
        // alert("Scroll Changed rowindex : " + info.rowIndex);
        self.scrollPosInfo(info);
      }
      self.connected = function () {
        //if (self.clickedKey() !== '') {
        //alert("Connected " + self.clickedKey());
        //self.scrollPos({
        //rowKey: self.clickedKey()
        //});
        //}
      }


      self.clone = function (obj) {
        var clone = {};
        for (k in obj) {
          if (k == 'idNum')
            clone[k] = Math.floor((Math.random() * 100000000000000) + 1).toString();
          else
            clone[k] = obj[k];
        }

        return clone;
      }


      self.transitionCompleted = function () {
        if (self.clickedIndex() !== '') {

          self.selectRowIndex(self.clickedIndex());

        }
      }
      self.selectRowIndex = function (index) {
        table = document.getElementById("table");
        table.selection = [{
          startIndex: {
            "row": index
          },
          endIndex: {
            "row": index
          }
        }];
      }

      self.showFunc = function () {
        //alert("Show Func");
      }

      self.serialize = function () {
        console.log("Self Object", self);
        self.firstName("Ayman");
        var st = ko.toJSON(self);
        self.firstName("No Ayman");
        console.log("Serialize String", st);
        window.localStorage.setItem("ser", st);
      }


      self.deserialize = function () {
        var st = window.localStorage.getItem("ser");

        // Every time data is received from the server:
        var vm = {};
        vm = map.fromJSON(st);
        Object.assign(vm, self);
        vm.showFunc();
        console.log("VM After JSON Deserilize", vm);


        Object.assign(vm, self);


        console.log("VM After Assign Object", vm);


        //dash.changeViewModel(vm,"searchothers");
        //map.fromJS(st,vm);
        //Object.assign(this,vm);
        //self = this;
        console.log("After Mapping", self);
        console.log("Paging Data Provider", self.pagingDataProvider);

        var table = document.getElementById('table');
        //table.setProperty("data",self.pagingDataProvider);
        console.log("Table Data", table.data);
        //table.data = self.pagingDataProvider ;
        table.refresh();
        return;

        var obj = JSON.parse(st);
        console.log("The deserializeed Object", obj);
        Object.assign(self, obj);

        console.log("After Assign Object", self);
        self.redrivedData = ko.observableArray(self.redrivedData);



        console.log("deSerialize", obj);
      }


      self.clearTable = function () {
        var o = self.redrivedData()[0];

        console.log("O", self.redrivedData()[0]);
        self.dataprovider.reset([]);
        self.redrivedData.removeAll();
        //self.redrivedData.push([o]);
      }
      self.tableListener = function () {
        var table = document.getElementById('table');

        var currentStateofviewModel = {
          name: 'searchothers',
          state: '/dashboard/searchothers',
          gridIndex: table.currentRow.rowIndex,
          idNumber:window.localStorage.getItem('idnumber'),
          viewModel: self//map.toJSON(self,mapping)
        }
        console.log("to JS",currentStateofviewModel.viewModel);
        
        app.addHistory(currentStateofviewModel);

        self.clickedIndex(table.currentRow.rowIndex);
        self.nationalIdNum(table.currentRow.rowKey);
      
        self.router = oj.Router.rootInstance;
        self.router.go('personDetails');

        window.localStorage.setItem('idnumber', self.nationalIdNum());
      }
    }

    return SearchOthersViewModel;
  }
);
