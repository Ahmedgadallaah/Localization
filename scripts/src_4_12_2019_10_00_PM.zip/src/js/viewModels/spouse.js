/**
 * @license
 * Copyright (c) 2014, 2019, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 */
/*
 * Your incidents ViewModel code goes here
 */
define(['ojs/ojcore', 'knockout', 'jquery', 
'viewModels/helpers/ipConfig', 'viewModels/helpers/fecthandcache_personspouseinfo',
'ojs/ojcheckboxset', 'ojs/ojformlayout', 'ojs/ojarraydataprovider', 'ojs/ojtable',
    'ojs/ojinputtext', 'ojs/ojbutton',
    'ojs/ojvalidationgroup', 'ojs/ojcollectiontabledatasource'
  ],
  function (oj, ko, $, ipConfig,spouseInfo) {

    function IncidentsViewModel() {
      var self = this;
      self.tracker = ko.observable();
      self.groupValid = ko.observable();
      self.personalIdentityNumber = ko.observable();


      self.persons = ko.observableArray([]);
      self.dataprovider = new oj.ArrayDataProvider(self.persons, {
        keyAttributes: 'idNum',
        implicitSort: [{
          attribute: 'fullName',
          direction: 'ascending'
        }]
      });
      self.tableColumns = [{
          "headerText": "الاسم",
          "field": "fullName",
          "resizable": "enabled"
        },
        {
          "headerText": "رقم الهوية",
          "field": "idNum",
          "resizable": "enabled"
        },
        {
          "headerText": "اسم الام",
          "field": "spouseMotherName",
          "headerClassName": "oj-sm-only-hide",
          "className": "oj-sm-only-hide",
          "resizable": "enabled"
        },
        {
          "headerText": "تاريخ الطلاق/الزواج",
          "field": "eventDate",
          "resizable": "enabled"
        },
        {
          "headerText": "تاريخ الميلاد",
          "field": "spouseBirthDate",
          "headerClassName": "oj-sm-only-hide",
          "className": "oj-sm-only-hide",
          "resizable": "enabled"
        },
        {
          "headerText": "حالة الزواج",
          "field": "spouseType",
          "resizable": "enabled"
        }
      ];

      // self.SpouseProfile = {
      //   "requestType": "62",
      //   "idNum": self.personalIdentityNumber(),
      //   "CSOHeader": {
      //     "OrganizationCode": "10-10",
      //     "UserName": "AZEID",
      //     "UserIdnum": "27508122700611",
      //     "TransactionNumber": "1010",
      //     "RequestTimeStamp": "2019-06-02 10:10:10.000000",
      //     "ResponseTimeStamp": ""
      //   }
      // }

      // self.url = "http://192.168.1.202:7003/CSO_SBProject/GetSpouseProfileRestService";

      // self.collection = null;
      // self.submit = function() {

      //   self.collection = new  oj.Collection(null,{customURL : function(){
      //           return self.url;
      //   }});

      //   self.collection.fetch({success:function(cols,reponse,options){
      //        console.log("Collection Data" , response);
      //   }});


      // }

      self.submit = function () {



        if (tracker.valid === "valid") {
          self.SpouseProfile.idNum = self.personalIdentityNumber();
          console.log(self.SpouseProfile);
          document.getElementById("load").style.visibility = "visible";
          document.getElementById("loader").style.visibility = "visible";
                    

          spouseInfo.setIdNumber(self.personalIdentityNumber());

          spouseInfo.getData().then(function(data){
            document.getElementById("loader").style.visibility = "hidden";
                    document.getElementById("load").style.visibility = "hidden";
            console.log('DATA: ', data);

            obj = JSON.parse(JSON.stringify(data.ResponseSpouseProfile));

            for (i = 0; i < obj.length; i++) {
              obj[i].spouseType = obj[i].spouseType.trim();
              if (obj[i].spouseType == '1') {
                obj[i].spouseType = 'قائمة';
              } else if (obj[i].spouseType == '2') {
                obj[i].spouseType = 'غير قائمة';
              }
            }


            self.persons(obj);

            // obj = JSON.parse(data.ResponseSpouseProfile);
            // self.persons(obj);
            console.log(data.ResponseSpouseProfile);
          });
          // $.ajax({

          //   'type': 'POST',
          //   'url': 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/CSO_SBProject/GetSpouseProfileRestService',
          //   'data': JSON.stringify(self.SpouseProfile),
          //   'dataType': 'json',
          //   'contentType': 'application/json'
          // }).done(function (data) {
          //   document.getElementById("load").style.visibility = "hidden";
          //   console.log('DATA: ', data);

          //   obj = JSON.parse(JSON.stringify(data.ResponseSpouseProfile));

          //   for (i = 0; i < obj.length; i++) {
          //     obj[i].spouseType = obj[i].spouseType.trim();
          //     if (obj[i].spouseType == '1') {
          //       obj[i].spouseType = 'قائمة';
          //     } else if (obj[i].spouseType == '2') {
          //       obj[i].spouseType = 'غير قائمة';
          //     }
          //   }


          //   self.persons(obj);

          //   // obj = JSON.parse(data.ResponseSpouseProfile);
          //   // self.persons(obj);
          //   console.log(data.ResponseSpouseProfile);
          // }).fail(function (error) {
          //   console.log('Error: ', console.log(error));
          // });

        } else {
          // show messages on all the components 
          // that have messages hidden.
          tracker.showMessages();
          tracker.focusOn("@firstInvalidShown");
        }
      }

    }

    return IncidentsViewModel;
  }
);