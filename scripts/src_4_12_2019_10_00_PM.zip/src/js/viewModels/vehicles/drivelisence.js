define(['ojs/ojcore', 'knockout', 'jquery',
    'viewModels/helpers/ipConfig', 'viewModels/helpers/fetchandcache_drivinglicense',
    'ojs/ojformlayout', 'ojs/ojpagingtabledatasource',
    'ojs/ojarraytabledatasource',
    'ojs/ojinputtext', 'ojs/ojbutton', 'ojs/ojpagingtabledatasource',
    'ojs/ojarraytabledatasource', 'ojs/ojpagingcontrol',
    'ojs/ojradioset',
    'ojs/ojcollectiontabledatasource', 'ojs/ojmodule-element-utils',
    'ojs/ojvalidationgroup', 'ojs/ojarraydataprovider', 'ojs/ojtable', 'ojs/ojmessages'
  ],
  function (oj, ko, $, ipConfig, carInfo) {

    function DrivingLicenseViewModel() {
      var self = this;
      self.nationalIdNum = window.localStorage.getItem('idnumber');
      console.log("idnumber", self.nationalIdNum);
      //  self.fetchAllData = new fetchAllDataClass();
      self.tracker = ko.observable();
      self.carID = ko.observable();
      self.clickedIndex = ko.observable("");
      self.groupValid = ko.observable();
      self.identityNum = ko.observable('');
      self.vechils = ko.observableArray([]);
      self.plateNum = ko.observable('');
      self.selection = ko.observable(true);
      self.currentSelection = ko.observable("رقم الهوية");

      self.status = ko.observable(0);
      self.errorMessages = ko.observableArray([]);
      self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);

      self.dataprovider = new oj.ArrayTableDataSource(self.vechils, {
        idAttribute: 'LNUM',
        sortCriteria: {
          key: 'LNUM',
          direction: 'ascending'
        }
      });

      self.pagingDataProvider =
        new oj.PagingTableDataSource(self.dataprovider);


      self.tableColumns = [{
          "headerText": "",
          "field": "ID",
          "renderer": oj.KnockoutTemplateUtils.getRenderer("serial", true)
        },
        {
          "headerText": "إسم المواطن",
          "field": "FULLNAME",
          "resizable": "enabled"
        },
        {
          "headerText": "رقم الرخصة",
          "field": "LNUM",
          "resizable": "enabled"
        },
        {
          "headerText": "وحدة المرور",
          "field": "ISSUEPLACENAME",
          "resizable": "enabled"
        },
        {
          "headerText": "نوع الرخصة",
          "field": "TYPENAME",
          "resizable": "enabled"
        },

        {
          "headerText": "تاريخ الإصدار",
          "field": "ISSUEDATE",
          "resizable": "enabled"
        },
        {
          "headerText": "نهاية الرخصة",
          "field": "EXPIRYDATE",
          "resizable": "enabled"
        }
      ];

      self.isSearchButtonDisabled = ko.observable(true);
      self.identityNumMessages = ko.observableArray([]);
      self.identityNum.subscribe(function (val) {
        self.identityNumMessages([]);
        self.isSearchButtonDisabled(false);
        console.log("Is Valid", isNaN(val));
        if ((val.length != 14) || isNaN(val)) {
          self.isSearchButtonDisabled(true);
          self.identityNumMessages.push({
            severity: "warning",
            summary: "الصيغة غير صحيحة",
            detail: "يجب أن يتم إدخال أرقام ويكون الرقم مكون من 14 رقم فقط"
          });
        } else {
          self.isSearchButtonDisabled(false);
        }

      })


      self.doSearch = function () {
        self.errorMessages([]);
        self.vechils([]);
        if (tracker.valid == 'valid') {
          // console.log("Car Request", self.personVechilsRequest);
          document.getElementById("loader").style.visibility = "visible";
          document.getElementById("load").style.visibility = "visible";
          // carInfo.setIdNumber(self.nationalIdNum);
          carInfo.setIdNumber(self.identityNum());
          carInfo.getData().then(function (data) {

            if (typeof data.getDLInfoOutput === 'undefined') {
              document.getElementById("loader").style.visibility = "hidden";
              document.getElementById("load").style.visibility = "hidden";

              self.errorMessages.push({
                severity: "error",
                summary: "خطأ",
                detail: "لاتوجد بيانات مركبات "
              });

              return;
            }
            console.log("Data Retrieved", data);
            var obj = JSON.parse(JSON.stringify(data.getDLInfoOutput));
            if (data != null) {
              document.getElementById("loader").style.visibility = "hidden";
              document.getElementById("load").style.visibility = "hidden";

              self.status(0);
              self.vechils(obj);
              var ar = data.getDLInfoOutput;
              ar.forEach(function (item) {
                self.iterate(item);
              });

              var change = ar
              change.forEach(function (ele) {

                self.changeData(ele);

              })
              self.vechils(change);
              scrollTo(0, 500);
              console.log('Cars Data: ', self.vechils());
              console.log('Data: ', data);
            } else {
              self.status(1);
              self.vechils.removeAll();
            }
          }).catch(function (error) {
            document.getElementById("loader").style.visibility = "hidden";
            document.getElementById("load").style.visibility = "hidden";

            self.errorMessages.push({
              severity: "error",
              summary: "خطأ استرجاع بيانات المركبات",
              detail: error.statusText
            });
            console.log("error", error);
          });
          //self.fetchAllData.getData();
        } else {

          tracker.showMessages();
          tracker.focusOn("@firstInvalidShown");
        }

      }


      self.clone = function (obj) {
        var clone = {};
        for (k in obj) {
          if (k == 'idNum')
            clone[k] = Math.floor((Math.random() * 100000000000000) + 1).toString();
          else
            clone[k] = obj[k];
        }

        return clone;
      }
      self.transitionCompleted = function () {
        if (self.clickedIndex() !== '') {

          self.selectRowIndex(self.clickedIndex());

        }
      }
      self.selectRowIndex = function (index) {
        table = document.getElementById("table");
        table.selection = [{
          startIndex: {
            "row": index
          },
          endIndex: {
            "row": index
          }
        }];
      }

      self.tableListener = function () {
        var table = document.getElementById('table');
        self.clickedIndex(table.currentRow.rowIndex);
        self.carID(table.currentRow.rowKey);
        console.log(self.plateNum());
        var car = self.vechils().find(function (element) {
          return element.ID === self.carID();
        });
        console.log('car object', car);
        self.router = oj.Router.rootInstance;
        self.router.getState('car').value = car;
        self.router.go('car');

      }


      self.iterate = function (obj) {
        for (k in obj) {
          if (self.isObject(obj[k])) {
            obj[k] = "--";
          }
          if (self.isNaN(obj[k])) {
            obj[k] = " ";
          }

        }
      }
      self.isObject = function (val) {
        return typeof val === "object";
      }
      self.isNaN = function (val) {
        return typeof val === "NaN";
      }
      self.changeData = function (row) {
        for (k in row) {
          if (k == 'ISSUEDATE') {
            row[k] = new Date(row[k]).toLocaleDateString()
          }
          if (k == 'EXPIRYDATE') {
            row[k] = new Date(row[k]).toLocaleDateString()
          }
        }
      }

      self.connected = function () {
        var carIdentity = document.getElementById("carIdentity");
        console.log("element", carIdentity);

        carIdentity.addEventListener("keyup", function (event) {
          if (event.keyCode == 13 && self.isSearchButtonDisabled() != true) {

            self.doSearch();

          }
        });
      }
    }

    return new DrivingLicenseViewModel();
  }
);