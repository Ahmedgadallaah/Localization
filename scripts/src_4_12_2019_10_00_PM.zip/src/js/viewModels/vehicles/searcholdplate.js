define(['ojs/ojcore', 'knockout', 'jquery', 'viewModels/helpers/ipConfig', 'ojs/ojformlayout',
        'ojs/ojinputtext', 'ojs/ojbutton', 'ojs/ojselectcombobox','ojs/ojpagingtabledatasource',
        'ojs/ojarraytabledatasource','ojs/ojpagingcontrol',
        'ojs/ojvalidationgroup', 'ojs/ojarraydataprovider', 'ojs/ojtable', 'ojs/ojmessages'
    ],
    function (oj, ko, $, ipConfig) {

        function SearchOldPlateViewModel() {

            var self = this;
            self.errorMessages = ko.observableArray([]);
            self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);
            self.clickedIndex = ko.observable("");
            self.vechils = ko.observableArray([]);
            self.carID = ko.observable();
            self.tracker = ko.observable();
            self.groupValid = ko.observable();
            self.plateNum = ko.observable('');
            
            self.carPlateNum = ko.observable('');
            self.selectedGov = ko.observable('');
            self.selectedType = ko.observable('');
            self.govs = ko.observableArray([]);
            self.types = ko.observableArray([]);

            self.status = ko.observable('0');

            self.dataprovider = new oj.ArrayTableDataSource(self.vechils, {
                idAttribute: 'ID',
                sortCriteria: {
                    key: 'fullName',
                    direction: 'ascending'
                }
            });




            self.isSearchButtonDisabled = ko.observable(true);
            self.identityNumMessages = ko.observableArray([]);
            self.plateNum.subscribe(function (val) {
              self.identityNumMessages([]);
              self.isSearchButtonDisabled (false);
              console.log("Is Valid" , isNaN(val));
              if ( ((val.length == 0 || val.length > 6))  ||isNaN(val) ) {
                self.isSearchButtonDisabled(true);
                self.identityNumMessages.push({
                  severity: "warning",
                  summary: "الصيغة غير صحيحة",
                  detail: "يجب أن يتم إدخال أرقام ويكون الرقم مكون من 14 رقم فقط"
                });
              }
              else
              {
                self.isSearchButtonDisabled(false);
              }
      
            })
      



            self.pagingDataProvider = 
            new oj.PagingTableDataSource(self.dataprovider);

            self.tableColumns = [{
                "headerText": "",
                "field": "idNum",
                "renderer": oj.KnockoutTemplateUtils.getRenderer("serial", true)
            },
            {
                "headerText": "رقم اللوحة",
                "field": "PLATENUM",
                "resizable": "enabled"
            },
            {
              "headerText": "وحدة المرور",
              "field": "ADDRESSPOLICESTATIONNAME",
              "resizable": "enabled"
          },
        
            {
              "headerText": "نوع اللوحة",
              "field": "PLATETYPENAME",
              "resizable": "enabled"
          },
             {
                "headerText": "الماركة",
                "field": "MAKENAME"
            },
            {
                "headerText": "الموديل ",
                "field": "MODELNAME",
                "resizable": "enabled"
            },
            {
                "headerText": "النوع ",
                "field": "FORMNAME",
                "headerClassName": "oj-sm-only-hide",
                "className": "oj-sm-only-hide",
                "resizable": "enabled"
            },
            {
                "headerText": "اللون",
                "field": "COLORNAME",
                "headerClassName": "oj-sm-only-hide",
                "className": "oj-sm-only-hide",
                "resizable": "enabled"
            },
            {
                "headerText": "المحافظة",
                "field": "GOVNAME",
                "resizable": "enabled"
            },
         
        ];


            // ,
            //     {"headerText": "رقم اللوحة", 
            //       "field": "PLATENUM",
            //       "resizable": "enabled"},
            //     {"headerText": "ماركة السيارة", 
            //       "field": "MAKENAME"},
            //     {"headerText": "موديل السيارة", 
            //       "field": "MODELNAME",
            //       "resizable": "enabled"},
            //     {"headerText": "نوع السيارة", 
            //       "field": "FORMNAME",
            //       "headerClassName": "oj-sm-only-hide",
            //       "className": "oj-sm-only-hide",
            //       "resizable": "enabled"},
            //     {"headerText": "لون السيارة", 
            //     "field": "COLORNAME",
            //     "headerClassName": "oj-sm-only-hide",
            //     "className": "oj-sm-only-hide",
            //     "resizable": "enabled"},
            //     {"headerText": "المحافظة", 
            //       "field": "GOVNAME",
            //       "resizable": "enabled"},
            //     {"headerText": "نوع اللوحة", 
            //       "field": "PLATETYPENAME",
            //       "resizable": "enabled"},

            self.getGovsUrl = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/TIT_SBProject/GetGovsRestService';
            self.getTypesUrl = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/TIT_SBProject/GetPlateTypeRestService';
            self.getCarUrl = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/TIT_SBProject/TITInfoRestService';
            self.errorMessages([]);
            self.getGovs = function () {

                $.ajax({
                    url: self.getGovsUrl,
                    type: 'GET',

                }).done(function (data) {

                    self.govs(data.Gov.map(function (item) {
                        return {
                            value: item.govid,
                            label: item.govname
                        }
                    }));
                    self.govs.unshift({
                        value: -1,
                        label: "الجميع"
                    });
                    console.log('GOVS: ', self.govs());
                }).fail(function (error) {



                    console.log(error);
                });
            };

            self.getTypes = function () {

                $.ajax({
                    url: self.getTypesUrl,
                    type: 'GET',

                }).done(function (data) {

                    self.types(data.Platetype.map(function (item) {
                        return {
                            value: item.platetype,
                            label: item.platetypename
                        }
                    }));
                    self.types.unshift({
                        value: -1,
                        label: "الجميع"
                    });



                    console.log('Types: ', self.types());
                }).fail(function (error) {
                    console.log(error);
                });
            };

            self.getGovs();
            self.getTypes();


            self.isButtonDisabled = ko.computed(function () {
                var bool = self.plateNum().length == 0 
                             
                console.log("IsButtonDisabled", bool);
                return bool;
              });
            self.doSearch = function () {
                self.errorMessages([]);
                self.vechils([]);
                if (tracker.valid == 'valid') {
                    document.getElementById("loader").style.visibility = "visible";
                    document.getElementById("load").style.visibility = "visible";

                    self.carRequest = {
                        "pnum": '',
                        "pnum1": '',
                        "pnum2": '',
                        "platenum": self.plateNum(),
                        "platenum1": self.plateNum(),
                        "ptype": self.selectedType() == -1 ? "" : self.selectedType(),
                        "govid": self.selectedGov() == -1 ? "" : self.selectedGov()
                    }

                    console.log("Car Request", self.carRequest);
                    $.ajax({
                        url: self.getCarUrl,
                        type: 'POST',
                        data: JSON.stringify(self.carRequest),
                        contentType: 'application/json',
                        dataType: 'json',
                        traditional: true

                    }).done(function (data) {

                        document.getElementById("loader").style.visibility = "hidden";
                        document.getElementById("load").style.visibility = "hidden";

                        if (typeof data === 'undefined' || typeof data.getTITInfoOutput === 'undefined') {

                            self.errorMessages.push({
                                severity: "error",
                                summary: "خطأ",
                                detail: "لاتوجد بيانات للمركبه "
                            });

                            return;
                        }
                        if (data != null) {
                            self.status('0');
                            self.vechils(data.getTITInfoOutput);

                            var ar = data.getTITInfoOutput;
                            ar.forEach(function (item) {
                                self.iterate(item);
                            });
                            self.vechils(ar);
                            scrollTo(0, 500);
                            console.log('Car Data', data);

                        } else {
                            self.status('1');
                            self.vechils([]);
                        }
                    }).fail(function (error) {
                        document.getElementById("loader").style.visibility = "hidden";
                        document.getElementById("load").style.visibility = "hidden";
                        self.errorMessages.push({
                            severity: "error",
                            summary: "خطأ استرجاع بيانات المركبه",
                            detail: error.statusText
                        });
                        console.log(error);
                    });
                } else {
                    tracker.showMessages();
                    tracker.focusOn("@firstInvalidShown");
                }

            }


self.clone = function (obj) {
        var clone = {};
        for (k in obj) {
          if (k == 'idNum')
            clone[k] = Math.floor((Math.random() * 100000000000000) + 1).toString();
          else
            clone[k] = obj[k];
        }

        return clone;
      }
      self.transitionCompleted = function () {
        if (self.clickedIndex() !== '') {
          
          self.selectRowIndex(self.clickedIndex());

        }
      }
      self.selectRowIndex = function(index){
        table = document.getElementById("table");
        table.selection = [{
          startIndex: {
            "row": index
          },
          endIndex: {
            "row": index
          }
        }];
      }


            self.tableListener = function () {
                var table = document.getElementById('table');
                self.clickedIndex(table.currentRow.rowIndex);
                self.carID(table.currentRow.rowKey);
                console.log(self.carPlateNum());
                var car = self.vechils().find(function (element) {
                    return element.ID === self.carID();
                });

                self.router = oj.Router.rootInstance;
                self.router.getState('car').value = car;
                self.router.go('car');


            }

            self.iterate = function (obj) {
                for (k in obj) {
                  if (self.isObject(obj[k])) {
                    obj[k] = " ";
                  }
                  if (self.isNaN(obj[k])) {
                    obj[k] = " ";
                  }
        
                }
              }
              self.isObject = function (val) {
                return typeof val === "object";
              }
              self.isNaN = function (val) {
                return typeof val === "NaN";
              }
        

            self.connected = function () {

                var caroldIdentity = document.getElementById("caroldIdentity");
                console.log("element", caroldIdentity);

                caroldIdentity.addEventListener("keyup", function (event) {
                    if (event.keyCode == 13  &&  self.isSearchButtonDisabled() != true) {
                        if (tracker.valid == 'valid') {
                            self.doSearch();
                        }



                    }
                });


            }
        }

        return new SearchOldPlateViewModel();
    }
);