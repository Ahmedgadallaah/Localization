define(['ojs/ojcore', 'knockout', 'jquery', 'viewModels/helpers/ipConfig', 'ojs/ojformlayout',
    'ojs/ojinputtext', 'ojs/ojbutton', 'ojs/ojpagingtabledatasource',
    'ojs/ojarraytabledatasource', 'ojs/ojpagingcontrol',
    'ojs/ojvalidationgroup', 'ojs/ojarraydataprovider', 'ojs/ojtable', 'ojs/ojmessages', 'ojs/ojmessaging'
  ],
  function (oj, ko, $, ipConfig) {
    function CarViewModel() {
      var self = this;
      self.plateNum = ko.observable('');

      self.isSearchButtonDisabled = ko.observable(true);
      self.identityNumMessages = ko.observableArray([]);

      self.tracker = ko.observable();
      self.groupValid = ko.observable();
      self.status = ko.observable('0');
      self.car = ko.observableArray([]);
      self.carID = ko.observable();
      self.errorMessages = ko.observableArray([]);
      self.errorMessagesProvider = new oj.ArrayDataProvider(self.errorMessages);


      self.dataprovider = new oj.ArrayTableDataSource(self.car, {
        idAttribute: 'ID',
        sortCriteria: {
          key: 'fullName',
          direction: 'ascending'
        }
      });

      self.pagingDataProvider = new oj.PagingTableDataSource(self.dataprovider);



      self.tableColumns = [{
          "headerText": "",
          "field": "idNum",
          "renderer": oj.KnockoutTemplateUtils.getRenderer("serial", true)
        },
        {
          "headerText": "رقم اللوحة",
          "field": "PLATENUM",
          "resizable": "enabled"
        },
        {
          "headerText": "وحدة المرور",
          "field": "ADDRESSPOLICESTATIONNAME",
          "resizable": "enabled"
        },

        {
          "headerText": "نوع اللوحة",
          "field": "PLATETYPENAME",
          "resizable": "enabled"
        },
        {
          "headerText": "الماركة",
          "field": "MAKENAME"
        },
        {
          "headerText": "الموديل ",
          "field": "MODELNAME",
          "resizable": "enabled"
        },
        {
          "headerText": "النوع ",
          "field": "FORMNAME",
          "headerClassName": "oj-sm-only-hide",
          "className": "oj-sm-only-hide",
          "resizable": "enabled"
        },
        {
          "headerText": "اللون",
          "field": "COLORNAME",
          "headerClassName": "oj-sm-only-hide",
          "className": "oj-sm-only-hide",
          "resizable": "enabled"
        },
        {
          "headerText": "المحافظة",
          "field": "GOVNAME",
          "resizable": "enabled"
        },

      ];



      self.url = 'http://' + ipConfig.firstOctet + '.' + ipConfig.secondOctet + '.' + ipConfig.thirdOctet + '.' + ipConfig.fourthOctet + ':' + ipConfig.portNumber + '/TIT_SBProject/TITInfoRestService';




      self.plateNum.subscribe(function (val) {
        self.identityNumMessages([]);
        self.isSearchButtonDisabled(false);
        console.log("Is Valid", isNaN(val));
        if ((val.length == 0 || val.length > 7)) {
          self.isSearchButtonDisabled(true);

          self.identityNumMessages.push({
            severity: "warning",
            summary: "الصيغة غير صحيحة",
            detail: "لايجب أن يتم إدخال أرقام وحروف ويكون التكوين من 1-7 ارقام فقط"
          });

          console.log("identityNumMessages", self.identityNumMessages())
        } else {
          self.isSearchButtonDisabled(false);
        }

      })




      self.doSearch = function () {
        self.errorMessages([]);
        self.car([]);
        self.carRequest = {
          "pnum": "",
          "platenum": self.plateNum(),
          "pnum1": "",
          "pnum2": "",
          "platenum1": self.plateNum(),
          "ptype": "",
          "govid": ""
        }
        document.getElementById("loader").style.visibility = "visible";
        document.getElementById("load").style.visibility = "visible";

        console.log(self.carRequest)

        $.ajax({
          url: self.url,
          type: 'POST',
          data: JSON.stringify(self.carRequest),
          contentType: 'application/json',
          dataType: 'json',

        }).done(function (data) {
          document.getElementById("loader").style.visibility = "hidden";
          document.getElementById("load").style.visibility = "hidden";

          if (typeof data === 'undefined' || typeof data.getTITInfoOutput === 'undefined') {

            self.errorMessages.push({
              severity: "error",
              summary: "خطأ",
              detail: "لاتوجد بيانات للمركبه "
            });

            return;
          }
          if (data != null) {
            self.status('0');
            self.car(data.getTITInfoOutput);
            var ar = data.getTITInfoOutput;
            ar.forEach(function (item) {
              self.iterate(item);
            });
            self.car(ar);
            scrollTo(0, 500);
            console.log('car data returned: ', data.getTITInfoOutput);
          } else {
            self.status('1');
            //self.car('');

          }
        }).fail(function (error) {
          document.getElementById("loader").style.visibility = "hidden";
          document.getElementById("load").style.visibility = "hidden";

          self.errorMessages.push({
            severity: "error",
            summary: "خطأ استرجاع بيانات المركبه",
            detail: error.statusText
          });
          console.log(error);
        });
      }




      self.tableListener = function () {
        var table = document.getElementById('table');
        self.carID(table.currentRow.rowKey);
        console.log(self.plateNum());
        var car = self.car().find(function (element) {
          return element.ID === self.carID();
        });

        self.router = oj.Router.rootInstance;
        self.router.getState('car').value = car;
        self.router.go('car');

      }

      self.iterate = function (obj) {
        for (k in obj) {
          if (self.isObject(obj[k])) {
            obj[k] = " ";
          }
          if (self.isNaN(obj[k])) {
            obj[k] = " ";
          }

        }
      }
      self.isObject = function (val) {
        return typeof val === "object";
      }
      self.isNaN = function (val) {
        return typeof val === "NaN";
      }

      self.connected = function () {

        var platIdentity = document.getElementById("platIdentity");
        console.log("element", platIdentity);

        platIdentity.addEventListener("keyup", function (event) {
          if (event.keyCode == 13 && self.isSearchButtonDisabled() != true) {

            self.doSearch();

          }
        });


      }
    }

    return new CarViewModel();
  }
);